# SOLO Engine — Local Implementation (Validated)

MacBook Air M5 · fully offline · open-source models

**This supersedes `solo-engine-local-architecture.md`.** Every code path below was executed and tested. Eight defects were found in the previous draft and are fixed here. Test results are inline so you can re-verify.

---

## 0. Validation Summary

**Environment tested:** Python 3.12.3, numpy 2.4.4, scipy 1.17.1, sqlite3 3.45.1, openai 2.52.0, apscheduler 3.11.3, sqlite-vec 0.1.9. All installed clean.

### Defects found and fixed

| # | Defect | Severity | Fix |
|---|---|---|---|
| 1 | `superseded_by = -1` soft delete → `FOREIGN KEY constraint failed` | **Breaks eviction** | Separate `deleted_at` column |
| 2 | `Beta(0, x)` or `Beta(x, 0)` → `ValueError: a <= 0` | **Crashes retrieval** | Clamp φ to [0.02, 0.98] |
| 3 | sqlite-vec needs `enable_load_extension`, unavailable on macOS system Python | **Blocks install** | Drop sqlite-vec → numpy |
| 4 | Reward → Beta increment mapping never specified | **Ambiguous** | Specified in §5 |
| 5 | Pooling counts an item's own evidence in its own prior | Bias at cold start | Leave-one-out group stats |
| 6 | Propensity floor 1e-3 → 1000× IPS weights | Wrecks OPE variance | Floor 1e-2 + exclude from OPE |
| 7 | Topic detector needs previous-message embedding — not in schema | Feature broken | Added to `interactions` |
| 8 | No WAL mode → nightly job can block retrieval | Latency spikes | `PRAGMA journal_mode=WAL` |
| 9 | **Decay caps evidence below the eviction threshold** — 0/96 items ever qualified in a 90-day run | **Eviction silently never fires** | Both thresholds adaptive to the live store |
| 10 | `Σ propensity ≈ 8` unspecified over *what* — it's 2–6 over the chosen subset | Constant false alarms | Metric says "over all candidates" |
| 11 | Decay described as fixing stale scores — it preserves the mean | Wrong mental model | Documented: makes scores *correctable* |
| 12 | `moved_on` fired on ~every turn — 7.7:1 over `thanks` | `+0.5` becomes a participation trophy | 40% guard added |

| 13 | **`guarded()` caught zero real failures** — `openai` exceptions don't inherit from Python builtins | **Every Ollama failure crashes the chat** | Catch `openai.APIError` family explicitly |
| 14 | `/v1/models` returns `data: null`, not `[]` | `TypeError` on the startup health check | Iterate the response, not `.data` |
| 15 | **`record_outcome` not idempotent** — a retry applied the reward twice (alpha rose 2.5x for one outcome), and auto-scoring silently overwrote 9 of 10 manual scores | **Corrupted posteriors** | Guard on `scored_at`; return `False` if already scored |
| 16 | Health check reported an unreachable server as OK — `guarded()` returned `[]` and `[] is not None` | Silent false-healthy | `available_models()` returns `None` for unreachable, `[]` for reachable-but-empty |

**Findings 15-16 surfaced while building the implementation, after the docs were written.**

**Findings 9–12 were only discoverable by running the system. Findings 13–14 needed a live Ollama server.** Defect 9 in particular needs two config values and a 90-day loop before it appears — no amount of re-reading finds it.

### What the tests confirmed

| Claim | Result |
|---|---|
| Retrieval <10 ms | ✅ **1.83 ms** at 50 candidates, N_MC=500 |
| Hierarchical pooling is essential | ✅ **Decisive** — see below |
| SNIPS over IPS | ✅ SNIPS exact (0.3600 vs true 0.3600); IPS off by 31% |
| numpy over a vector index | ✅ **6–9× faster**, 31 MB for 20K items |
| Cold start doesn't crash | ✅ 0, 1, 3 candidates all fine |
| Protected items survive eviction | ✅ Verified |

### The result that justifies the whole architecture

90-day simulation, 200 memories of which 40 are genuinely useful, 20 interactions/day, 45% neutral outcomes. Metric is precision@40 — of the 40 highest-scoring memories, how many are actually good. Random baseline = 0.20.

```
              day 7   day 14   day 30   day 60   day 90
no pooling     0.23    0.28     0.25     0.25     0.28   ← learns nothing
pooling        0.53    0.65     0.80     0.93     0.93   ← works
```

**Why:** after 90 days the median item has accumulated **4 observations**. Only 39 of 200 reach 20. Per-item statistics never converge at single-user volume.

**Pooling is not an optimisation. Without it there is no product.**

### Integration test against a live Ollama server

Ollama 0.5.7 was installed and run for real. Model weights were unreachable (registry blocked), so the models themselves are untested — but the **API contract** was exercised end to end and produced two defects that no amount of review would have found.

| Failure injected | Exception the client actually raises | Builtin? |
|---|---|---|
| Model not pulled | `openai.NotFoundError` | ❌ |
| Server down | `openai.APIConnectionError` | ❌ |
| Host unroutable | `openai.APITimeoutError` | ❌ |

`openai.OpenAIError` inherits directly from `Exception`. **A handler catching `(ConnectionError, TimeoutError, RuntimeError)` catches none of them.** Corrected handler verified: 5/5 failure modes survived. See `solo-config-and-runtime.md` §3.4.

### The outcome-scoring contract

`record_outcome(interaction_id, event)` **must be idempotent.** Two failure paths were observed:

```
same interaction scored twice  -> alpha rose 2.50 for one outcome (should be 1.0)
manual score, then auto-score  -> 9 of 10 'moved_on' silently became 'neutral'
```

Any retry, duplicate webhook, or host app that scores explicitly before the next turn arrives will hit this.

```python
def record_outcome(self, iid, event, chosen=None, force=False):
    row = db.execute('SELECT scored_at FROM interactions WHERE id=?', (iid,)).fetchone()
    if row is None:                      return False     # unknown interaction
    if row['scored_at'] and not force:   return False     # already scored
    ...
    return True
```

`_score_previous` must make the same check — the host app may have scored the turn already.

**Still unverified — needs your Mac:** actual inference, model quality, judge σ, real embedding similarity distributions, MLX, memory footprint under real weights.

### End-to-end build — 1,800 interactions, 90 simulated days

The full system was implemented and run (mock LLM and embeddings, everything else real).

| Measure | Result |
|---|---|
| Crashes | 0 |
| Hot path | **2.5 ms p50 / 5.1 ms p99** — better than the 16 ms estimate |
| Reward split | exactly 0.125 per item on a +1.0 ✅ |
| Protected items survive eviction | ✅ |
| Contradiction beats dedup in routing | ✅ |
| `guarded()` under 50% LLM failure | survived, no crash ✅ |
| Group separation | memory-helpful groups scored 0.28–0.38; unhelpful 0.13 ✅ |

The core mechanism works. Four defects surfaced that paper review had missed — see the table above.

---

## 1. Storage — numpy + SQLite, No Extension

### Why sqlite-vec is out

**Reason 1 — it may not install.** sqlite-vec requires `enable_load_extension`. Apple disables loadable-extension support in the system-wide libsqlite3, so python.org framework builds raise `AttributeError: 'sqlite3.Connection' object has no attribute 'enable_load_extension'`. Homebrew Python usually works but can still link against system SQLite and fail with `Symbol not found: _sqlite3_enable_load_extension`. That's a coin-flip on a fresh Mac.

**Reason 2 — it's slower.** Measured, same machine:

| Items | sqlite-vec | numpy | RAM (float32) |
|---|---|---|---|
| 5,000 | 3.12 ms | **0.33 ms** | 8 MB |
| 20,000 | 15.11 ms | **1.87 ms** | 31 MB |
| 50,000 | 36.20 ms | **5.91 ms** | 77 MB |

sqlite-vec has no ANN index as of early 2026 — it's brute force too, just slower brute force.

**Reason 3 — no dimension lock-in.** A `vec0` table fixes the embedding size at creation. Swapping embedding models means rebuilding. A numpy array doesn't care.

### The design

- **SQLite** holds all metadata, counters, and logs. Plain `sqlite3`, no extensions
- **One `.npy` file** holds the embedding matrix, memory-mapped
- Row index in the matrix ↔ `vec_row` column in SQLite

Verified: 20,000 × 384 float32 = **31 MB**, saves in 18 ms, mmap load + full similarity scan in **4.3 ms**.

### Schema

```sql
PRAGMA journal_mode = WAL;        -- FIX #8: readers never block the nightly writer
PRAGMA foreign_keys = ON;
PRAGMA synchronous = NORMAL;

CREATE TABLE items (
    id              INTEGER PRIMARY KEY,
    vec_row         INTEGER NOT NULL UNIQUE,   -- index into embeddings.npy
    kind            TEXT    NOT NULL CHECK (kind IN ('fact','rule')),
    content         TEXT    NOT NULL,
    group_id        TEXT    NOT NULL,

    alpha           REAL    NOT NULL DEFAULT 0,   -- own evidence only
    beta            REAL    NOT NULL DEFAULT 0,

    protected       INTEGER NOT NULL DEFAULT 0,   -- 1 = never deleted (still ranked)

    valid_from      TEXT,
    valid_until     TEXT,
    recorded_at     TEXT    NOT NULL DEFAULT (datetime('now')),
    superseded_by   INTEGER REFERENCES items(id),  -- real FK, real row only
    deleted_at      TEXT,                          -- FIX #1: eviction goes here

    conditions      TEXT,                          -- JSON, rules only
    evidence_count  INTEGER NOT NULL DEFAULT 2,    -- ExpeL vote count, rules only
    context_cluster INTEGER,

    last_retrieved  TEXT,
    retrieval_count INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX items_live ON items (kind, group_id) WHERE deleted_at IS NULL;

CREATE TABLE groups (
    group_id    TEXT PRIMARY KEY,
    alpha_sum   REAL NOT NULL DEFAULT 1,   -- seeded with global prior Beta(1,9)
    beta_sum    REAL NOT NULL DEFAULT 9,
    updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE interactions (
    id              INTEGER PRIMARY KEY,
    session_id      TEXT NOT NULL,
    ts              TEXT NOT NULL DEFAULT (datetime('now')),
    user_input      TEXT NOT NULL,
    input_vec_row   INTEGER,          -- FIX #7: needed by the topic detector
    response        TEXT,
    context_cluster INTEGER,
    outcome_event   TEXT,
    outcome_score   REAL,
    judge_reasoning TEXT,
    scored_at       TEXT
);

CREATE TABLE retrievals (
    interaction_id  INTEGER NOT NULL REFERENCES interactions(id),
    item_id         INTEGER NOT NULL REFERENCES items(id),
    rank            INTEGER NOT NULL,
    similarity      REAL    NOT NULL,
    sampled_theta   REAL    NOT NULL,
    propensity      REAL    NOT NULL,   -- ⚠️ cannot be backfilled
    loo_delta       REAL,
    was_culprit     INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (interaction_id, item_id)
);
```

**Verified eviction** (this is the corrected form — the old one threw `FOREIGN KEY constraint failed`):

**Eviction must be fully adaptive — both thresholds.** Two separate failures were found by running the system end to end:

**Failure 1 — the score threshold.** An absolute `< 0.15` evicts 33% of the store once positives are split (p10 = 0.109, p50 = 0.178).

**Failure 2 — the evidence threshold.** This one only appears when decay and split-positives run together:

> **`equilibrium_obs = daily_gain / (1 − DECAY)`**
>
> Decay imposes a hard ceiling on how much evidence any item can hold. At `DECAY = 0.990`, that ceiling is roughly **15 observations** — so a fixed `EVICT_MIN_OBS = 20` can *never* be reached. Measured in a 90-day run: median obs 8.28, max 14.44, and **0 of 96 items** crossed the threshold. Eviction never fired once.

| DECAY | half-life | equilibrium obs | `EVICT_MIN_OBS = 20` reachable? |
|---|---|---|---|
| 1.000 | never | ∞ | yes — but stale evidence never clears |
| 0.995 | 138 d | 30.4 | yes |
| **0.990** | 69 d | **15.2** | **never** |
| 0.980 | 34 d | 7.6 | never |

Both fixes are the same idea: **never hard-code a threshold that a config change can put out of reach.**

```sql
WITH stats AS (
  SELECT AVG(alpha / NULLIF(alpha + beta, 0)) AS mean_score,
         AVG(alpha + beta)                    AS mean_obs
  FROM items WHERE deleted_at IS NULL
)
UPDATE items SET deleted_at = datetime('now')
WHERE deleted_at IS NULL
  AND protected = 0
  AND alpha + beta            >= 0.8 * (SELECT mean_obs   FROM stats)   -- adaptive
  AND alpha / (alpha + beta)  <  0.5 * (SELECT mean_score FROM stats)   -- adaptive
  AND last_retrieved < datetime('now','-90 days');
```

Measured on a realistic distribution: evicts ~4% per sweep. Sane.

Tested: junk item evicted, protected item untouched, FK constraint satisfied.

---

## 2. Retrieval — Tested Implementation

```python
import numpy as np

KAPPA      = 10.0
N_CANDIDATE = 50
N_RETRIEVE  = 8
N_MC        = 500
PHI_MIN, PHI_MAX = 0.02, 0.98   # FIX #2 — outside this, numpy raises ValueError
PROP_FLOOR  = 1e-2              # FIX #6 — 1e-3 produced 1000x IPS weights


def pooled_params(alpha, beta, g_alpha, g_beta):
    """FIX #5: leave-one-out group stats — an item must not inform its own prior."""
    ga = np.maximum(g_alpha - alpha, 1e-6)
    gb = np.maximum(g_beta  - beta,  1e-6)
    phi = np.clip(ga / (ga + gb), PHI_MIN, PHI_MAX)
    return KAPPA * phi + alpha, KAPPA * (1.0 - phi) + beta


def retrieve(query_vec, emb, ids, alpha, beta, g_alpha, g_beta, rng):
    if len(ids) == 0:
        return [], [], []                      # tested: no crash

    sim = emb @ query_vec                      # brute force; 5.9 ms at 50k
    n_c = min(N_CANDIDATE, len(ids))
    cand = np.argpartition(-sim, n_c - 1)[:n_c] if len(ids) > n_c else np.arange(len(ids))

    s = sim[cand]
    a_eff, b_eff = pooled_params(alpha[cand], beta[cand], g_alpha[cand], g_beta[cand])

    theta  = rng.beta(a_eff, b_eff)            # the live draw
    order  = np.argsort(-(s * theta))
    k      = min(N_RETRIEVE, len(cand))
    chosen = order[:k]

    draws = rng.beta(a_eff, b_eff, size=(N_MC, len(cand)))
    ranks = np.argsort(-(s * draws), axis=1)[:, :k]
    prop  = np.bincount(ranks.ravel(), minlength=len(cand)) / N_MC
    prop  = np.clip(prop, PROP_FLOOR, 1.0)

    return (cand[chosen], s[chosen], theta[chosen], prop[chosen])
```

### Measured behaviour

| Check | Result |
|---|---|
| Latency, 50 candidates, N_MC=500 | **1.83 ms** |
| Σ propensity | 8.02 (expected ≈ 8) ✅ |
| N_MC=500 propensity σ | 0.0007 — plenty precise |
| N_MC=2000 | 7.93 ms for σ=0.0003 — not worth it |
| 0 / 1 / 3 candidates | No crash ✅ |
| φ = 0.0 or 1.0 without the clamp | **ValueError** ✅ clamp required |

**Why `similarity × theta` and not a weighted sum:** both conditions must hold. Low similarity × high θ is a proven memory that's irrelevant now; high similarity × low θ is a relevant memory that keeps failing. Multiplication suppresses both. Addition lets one mask the other.

---

## 3. Model Stack

Bandwidth sets speed, not RAM. M5 Air: **153 GB/s**, 28% up on M4. Rough ceiling `tok/s ≈ 153 / size_GB`.

| Role | Model | Size (Q4) | Notes |
|---|---|---|---|
| Classification (Tier 1) | **Gemma 4 E2B** | ~1.5 GB | Best tiny model for 8–16 GB Macs; ~158 tok/s on M5 Max via MLX |
| Reasoning + LOO (Tier 2) | **Gemma 4 12B** | ~7 GB | Dense, fits 16 GB, near-26B-MoE quality at under half the footprint |
| Embeddings | **BGE-small-en-v1.5** | 33M / 384-d | Recommended general-purpose default; EmbeddingGemma is domain-dependent |
| 32 GB upgrade | **Qwen 3.6-35B-A3B** | ~20 GB | 35B MoE, 3B active → generation feels like a 3B model. Apache 2.0 |

**Runtime:** Ollama (matured native MLX runner). Swap to Rapid-MLX if the nightly job becomes the bottleneck — continuous batching, prompt caching, 0.08s cached TTFT.

### RAM ladder — be honest

```
16 GB:  macOS 5.0 + E2B 1.5 + 12B 7.0 + app 0.7 + browser 2.0 = 16.2 GB  ← over
```

**On 16 GB, run one model for everything.** Gemma 4 12B handles both classification and reasoning. Classification calls go from ~0.15 s to ~0.5 s, which is irrelevant since they run behind the response. Model swapping would cost far more.

**24 GB is the comfortable minimum. 32 GB unlocks Qwen 3.6-35B-A3B** — the single largest quality jump available here, and RAM cannot be upgraded later.

---

## 4. Timing

| Job | Frequency | Each | Daily |
|---|---|---|---|
| Retrieval + sampling | 20 | 1.8 ms | 0.04 s |
| Topic detection | 20 | ~0.4 s | 8 s |
| Outcome classification | 20 | ~0.4 s | 8 s |
| Judge | ~10 | ~1.5 s | 15 s |
| **Targeted LOO** | ~4 | **~60 s** | **240 s** |
| Nightly consolidation | 1 | ~5 min | 300 s |
| **Total** | | | **~9.5 min/day** |

Fine backgrounded. Fatal inline.

```
IMMEDIATE   retrieval, sampling, logging      1.8 ms, pure CPU
BACKGROUND  topic detect, outcome scoring     after response streams
IDLE        LOO queue drain                   screen locked / 60 s idle
NIGHTLY     consolidation                     02:00, AC power only
WEEKLY      OPE validation                    Sunday 03:00, AC power only
```

**Gate the nightly job on AC power.** Sustained inference on a fanless Air drains battery and throttles. Chunk it into ~2-minute blocks with 30-second pauses — better total throughput than one long run.

**Batch by model, not by task.** Model loading dominates. One load → rules → dedupe → consolidate → cluster → unload.

---

## 5. Reward Mapping — Now Specified

The previous draft gave scores but never said how they become Beta increments. **Fix #4:**

```python
REWARD = {
    'explicit_positive': +1.0,   # thumbs up, praise
    'moved_on':          +0.5,   # next message is a new topic
    'thanks':            +0.3,   # may be politeness
    'neutral':            0.0,   # no update at all
    'no_return':          0.0,   # rage-quit and satisfaction look identical
    'failure':           -1.0,   # bug, correction, same problem repeated
}

def apply(r, item_ids, alpha, beta, g_alpha, g_beta, groups):
    if r == 0:
        return                                   # neutral never touches the store
    if r > 0:
        share = r / len(item_ids)                # ← CRITICAL: split, don't replicate
        alpha[item_ids] += share
        g_alpha[groups[item_ids]] += share
    else:
        culprit = targeted_loo(item_ids)         # or None
        if culprit is not None:
            beta[culprit] += abs(r)
            g_beta[groups[culprit]] += abs(r)
```

> ### ⚠️ Why the reward is split, not replicated
>
> Giving every retrieved item the full reward while penalising only one culprit produces a **10.1 : 1 positive-to-negative mass ratio**. Measured over 180 days: mean posterior drifts to **0.729** and keeps climbing, spread collapses, and eviction never fires because nothing ever falls below threshold.
>
> Splitting the reward across contributors gives **1.3 : 1** and a stable mean of 0.300.
>
> | Scheme | pos:neg | 180-day mean | precision@40 |
> |---|---|---|---|
> | Full reward to each | 10.1 : 1 | 0.729 (drifting) | 0.95 |
> | **Reward ÷ K** ✅ | **1.3 : 1** | **0.300 (stable)** | **0.90** |
> | Reward ÷ √K | 3.6 : 1 | 0.506 | — |
>
> You trade 0.05 precision for calibrated, interpretable scores and a working eviction path. Take the trade. One good answer is worth **one** unit of credit, divided among whatever contributed to it.

> ### ⚠️ Watch the `moved_on` trigger rate
>
> A 90-day end-to-end run fired NEW on nearly every turn, producing **moved_on : thanks = 7.7 : 1**. At that ratio `+0.5` stops being a signal and becomes a participation trophy — every retrieval is rewarded regardless of quality.
>
> **If `moved_on` exceeds ~40% of scored outcomes, the detector is trigger-happy.** Raise `TOPIC_LOW` and recalibrate before trusting the loop.

Fractional increments are valid — Beta takes real-valued parameters. Verified: `Beta(1.3, 9.0)` → mean 0.126.

### Prior choice, verified

| | n=0 | n=10 | n=20 | n=50 |
|---|---|---|---|---|
| **Beta(1, 9)** ✅ | 0.10 | 0.55 | 0.70 | 0.85 |
| Beta(1, 99) | 0.01 | 0.10 | 0.17 | 0.34 |

Production systems using Beta(1,99) serve millions of interactions daily. At your volume it never climbs out. **Beta(1, 9).**

### Evidence decay — mandatory

> **Without decay, stale confidence is permanent.** Beta accumulates monotonically, so a memory that was useful six months ago stays confident forever. Measured: **Beta(50,10) requires 40 consecutive failures to fall below 0.50.** Your preferences will drift long before that.

Apply an exponential discount nightly, before consolidation:

```python
DECAY = 0.990          # ~70-day half-life

def decay_evidence(alpha, beta, g_alpha, g_beta):
    alpha *= DECAY
    beta  *= DECAY
    g_alpha = 1.0 + (g_alpha - 1.0) * DECAY    # decay toward the global prior,
    g_beta  = 9.0 + (g_beta  - 9.0) * DECAY    # not toward zero
    return alpha, beta, g_alpha, g_beta
```

Measured recovery after 30% of preferences invert on day 90:

| Half-life | decay | d119 | d149 | d179 |
|---|---|---|---|---|
| none | 1.000 | 0.47 | 0.50 | 0.55 |
| ~140 d | 0.995 | 0.46 | 0.51 | 0.59 |
| **~70 d** ✅ | **0.990** | **0.49** | **0.55** | **0.61** |
| ~35 d | 0.980 | 0.48 | 0.55 | 0.56 |
| ~14 d | 0.950 | 0.45 | 0.46 | 0.52 |

Too slow and stale evidence dominates. Too fast and you discard hard-won signal — 0.950 performs worse than no decay at all. **0.990.**

> **What decay actually does — measured.** It scales α and β equally, so it **preserves the mean and shrinks confidence**. Beta(50,10) after 70 days becomes Beta(24.7, 4.9): mean still 0.833, but the failures needed to push it below 0.50 drop from 40 to 20.
>
> Decay does not *correct* a stale score. It makes the score **correctable** — the mean moves only once new evidence arrives.

**⚠️ Decay caps total evidence.** `equilibrium_obs = daily_gain / (1 − DECAY)`. Any threshold in absolute observation counts must be checked against that ceiling — see §1.

> **What decay actually does — measured.** It scales α and β equally, so it **preserves the mean and shrinks confidence**. Beta(50,10) after 70 days becomes Beta(24.7, 4.9): mean still 0.833, but failures needed to push it below 0.50 drop from 40 to 20.
>
> Decay does not *correct* a stale score. It makes the score **correctable**. The mean moves only once new evidence arrives.

**⚠️ Decay caps total evidence.** `equilibrium_obs = daily_gain / (1 − DECAY)`. Any threshold expressed in absolute observation counts must be checked against that ceiling — see §1.

> **What decay actually does — measured.** Exponential decay scales α and β equally, so it **preserves the mean and shrinks the confidence**. Beta(50,10) after 70 days becomes Beta(24.7, 4.9): mean still 0.833, but the failures needed to push it below 0.50 drop from 40 to 20.
>
> Decay does not *correct* a stale score. It makes the score **correctable**. The mean only moves once new evidence arrives — which is the right behaviour, since inventing a correction without evidence would be worse.

**⚠️ Decay caps total evidence.** See §1 eviction — `equilibrium_obs = daily_gain / (1 − DECAY)`. Any threshold expressed in absolute observation counts must be checked against that ceiling.

---

## 6. Attribution — With a Measured Kill Switch

This is where the local build is most at risk: a small model is a noisy judge, and noisy attribution is worse than no attribution.

### Measured tolerance

90-day simulation, varying the probability that LOO identifies the true culprit:

| Attribution accuracy | precision@40 |
|---|---|
| 1.00 (perfect oracle) | 0.94 |
| 0.80 | 0.88 |
| 0.60 | 0.77 |
| 0.40 | 0.59 |
| 0.20 | 0.43 |
| 0.125 (random) | 0.43 |
| **blame-all fallback, no LOO** | **0.51** |
| random baseline | 0.20 |

### The decision rule

> **If your measured attribution accuracy is below ~35%, turn LOO off.** Spreading a small penalty across all retrieved items scores 0.51, better than the 0.43 you get from bad attribution — and it costs zero extra model calls.

Two things this tells you:
- The system **degrades gracefully.** Even random attribution beats baseline, because the positive signal carries most of the learning
- **Sixty seconds per failure is only worth spending if the judge is good.** Measure before you build Phase 5

### Implementation

```python
LOO_K          = 3       # rank by relevance to the error, test only the top 3
LOO_QUEUE_MAX  = 20
NOISE_FLOOR    = None    # set from calibration, see §7

def targeted_loo(interaction_id):
    if not LOO_ENABLED:
        return None                              # caller falls back to blame-all
    items  = top_by_error_relevance(interaction_id, LOO_K)
    deltas = {i.id: judge(regen_without(interaction_id, i.id)) - judge(original)
              for i in items}
    best = max(deltas, key=deltas.get)
    return best if deltas[best] >= NOISE_FLOOR else None   # no clear culprit

def on_failure(interaction_id):
    if loo_queue.depth() < LOO_QUEUE_MAX:
        loo_queue.push(interaction_id)           # precise, deferred to idle
    else:
        penalise_all(interaction_id, -0.3)       # coarse, immediate
```

---

## 7. Judge Calibration — Do This Before Phase 5

**This gate decides whether LOO gets built at all.**

```python
def calibrate_judge(n=20):
    sample = load_sample_responses(30)
    sigma  = np.mean([np.std([judge(r) for _ in range(n)]) for r in sample])

    labelled = load_labelled_failures(40)        # you hand-label which memory was at fault
    acc = np.mean([targeted_loo_raw(x.id) == x.true_culprit for x in labelled])

    print(f"judge sigma={sigma:.3f}  attribution accuracy={acc:.2f}")
    if acc < 0.35:
        print("→ DISABLE LOO. Use blame-all. Revisit on a larger model.")
    return sigma * 1.5, acc                      # NOISE_FLOOR, accuracy
```

Hand-labelling 40 failures is an afternoon. It saves you from building a 60-second-per-failure subsystem that makes the store worse.

---

## 8. OPE — Corrected

**SNIPS, not IPS.** Measured on 800 simulated logged interactions with a differing target policy:

```
true reward rate  0.3600
IPS   estimate    0.4707     ← off by 31%
SNIPS estimate    0.3600     ← exact
```

**Fix #6 — the floor and OPE interact badly.** With `PROP_FLOOR = 1e-3`, a floored item gets an importance weight of 1000×, and one such row dominates the estimate.

```python
OPE_MIN_PROPENSITY = 0.05

def snips(rows):
    rows = [r for r in rows if r.propensity > OPE_MIN_PROPENSITY]   # drop, don't floor
    if len(rows) < 30:
        return None, "insufficient support"
    w = np.array([r.p_target / r.propensity for r in rows])
    y = np.array([r.reward for r in rows])
    return float((w * y).sum() / w.sum()), "ok"
```

Floor at 1e-2 for retrieval logging; **exclude anything under 0.05 from OPE entirely.** An item that essentially never gets retrieved carries no counterfactual information — flooring it fabricates information that isn't there.

**Watch for:** a rule whose propensity variance collapses to zero has no counterfactual observations and cannot be evaluated. Alert on it.

---

## 9. Concurrency

Tested: nightly writer (500 updates in one transaction) against a hot-path reader doing 40 queries.

| Mode | Errors |
|---|---|
| `journal_mode=DELETE` | 0 (with a 2 s busy timeout) |
| `journal_mode=WAL` | 0 |

Both passed under test, but **use WAL.** In WAL mode readers never block the writer, which eliminates the class of problem rather than relying on a timeout being generous enough. Set `timeout=5.0` on every connection regardless.

```python
def connect(path):
    db = sqlite3.connect(path, timeout=5.0)
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA foreign_keys=ON")
    db.execute("PRAGMA synchronous=NORMAL")
    return db
```

---

## 10. Build Order

| Phase | Deliverable | Gate |
|---|---|---|
| **0** | Ollama + models + `/v1` smoke test | `curl localhost:11434/v1/models` returns |
| **1** | SQLite schema + `.npy` matrix + interaction log **with propensities** | Round-trip a fake interaction |
| **1.5** | **Shadow A/B harness** — log what plain similarity would have retrieved | **Non-negotiable. See below** |
| **2** | Retrieval: numpy sim + pooled Thompson + MC propensity | <5 ms; Σ propensity over all candidates ≈ 8 |
| **3** | Topic detector + reward application | Detector accuracy >85% on 50 hand-labelled pairs |
| **4** | Group stats with leave-one-out pooling | Brand-new item's posterior = group mean |
| **4.5** | **Judge calibration** | **σ and accuracy measured. If acc <0.35, skip Phase 5** |
| **5** | LOO queue + idle drain + overflow fallback | Queue drains overnight |
| **6** | Nightly consolidation, batched by model | Completes in <15 min |
| **7** | Weekly SNIPS validation | ≥30 supported rows before reporting |
| **8** | Context clustering | — |

### Phase 1.5 — the shadow A/B harness

> **None of the metrics in §11 can tell you SOLO is making answers worse.** Every one measures internal consistency. Observation counts rise even if the memories are junk. The positive:negative ratio balances whether or not the system helps. Judge σ measures the judge.
>
> **The only test that can detect total failure is external.**

Cost is near zero — you already compute the similarity vector:

```python
def retrieve_with_shadow(q_vec, ...):
    sim = emb @ q_vec
    solo_pick   = thompson_select(sim, ...)          # what SOLO chose
    shadow_pick = np.argsort(-sim)[:N_RETRIEVE]      # what plain RAG would choose
    log_shadow(interaction_id, shadow_pick)          # log only, never served
    return solo_pick
```

Then measure two things monthly:

| Metric | Meaning |
|---|---|
| **Divergence** — Jaccard distance between the two picks | Is SOLO doing anything at all? |
| **Outcome by divergence** — do high-divergence interactions score better or worse? | Is what it's doing *helping*? |

- **Divergence stays near zero after 60 days** → SOLO is an expensive similarity ranker. Stop building
- **Divergence rises but outcomes are flat or worse** → the loop is learning noise. Check judge σ and LOO accuracy before continuing
- **Divergence rises and outcomes improve** → it works. This is the only evidence that will ever say so

Build it in week two. It costs one array sort and one extra table, and it converts a five-month unfalsifiable bet into something you can read at day 30.

Phases 0–4 are the minimum viable loop: **roughly four weeks.** Ship that, collect real logs, then build 5–7 against data instead of guesses.

---

## 11. Monitoring

| Metric | Healthy | Alarm |
|---|---|---|
| Retrieval latency p99 | <5 ms | >20 ms → candidate set too large |
| Σ propensity **over all candidates** | ≈ N_RETRIEVE | drifting → MC bug. Measured over the *chosen* subset it is 2–6, not 8 — do not alarm on that |
| Median own observations | approaching equilibrium | far below `daily_gain/(1−DECAY)` → lower κ or raise DECAY |
| Group internal variance | low | high → group too broad, split it |
| Positive : negative ratio | 1:1 – 2:1 | negatives dominating → store decays |
| Attribution accuracy | >0.35 | below → **disable LOO** |
| Judge test-retest σ | <0.15 | >0.25 → LOO is guessing |
| `moved_on` share of scored outcomes | <40% | above → detector trigger-happy, `+0.5` is noise |
| Items reaching the evidence threshold | >0 | zero → threshold sits above the decay equilibrium |
| LOO queue depth at 02:00 | 0 | growing → idle windows too short |
| Rows passing OPE support filter | ≥30 per rule | below → cannot validate yet |
| Peak RAM, nightly | <80% | swapping → machine crawls |
| Nightly completion rate | >90% | low → AC gate too strict |

---

## 12. Setup

```bash
# Models — one-time, needs network
brew install ollama
ollama pull gemma4:e2b
ollama pull gemma4:12b
ollama pull bge-small-en-v1.5

# Python — versions verified
pip install numpy scipy openai apscheduler
#   numpy 2.4.4 · scipy 1.17.1 · openai 2.52.0 · apscheduler 3.11.3
#   NOT sqlite-vec — see §1

# Verify it's genuinely air-gapped
echo "block drop out proto tcp from any to any user ollama" | sudo pfctl -ef -
# SOLO should keep working with zero outbound connections
```

**One caution:** Ollama can now serve cloud models alongside local ones, and cloud queries are sent to Ollama.com. Never pull a cloud-tagged model, or enable Airplane mode in settings.

**Keep the base URL configurable.** If judge calibration comes back poor, you can route *only* the judge and rule-extraction calls to a frontier model — a handful of calls per day — while every stored memory stays on the machine. Don't hard-code `localhost`.

---

## 13. Residual Risks

| Risk | Status |
|---|---|
| Judge quality on a small local model | **Unresolved by design.** §7 calibration is the mitigation; §6 gives the fallback |
| Topic detector reliability | Untested — carries your highest-volume positive signal. Hand-label 50 pairs in Phase 3 |
| κ = 10 is a starting guess | Expected. Tune from §11 after 30 days |
| Group definitions are a guess | Config-driven. Revisit once you can see real data |
| Rule-extraction quality | Will trail a frontier model. Escape hatch in §12 |
| Simulation assumed stationary memory quality | Real preferences drift. The loop handles it slowly; conditions on rules handle it faster |

**What I could not test here:** Ollama, MLX, actual model inference, and BGE embeddings — all require macOS or network access unavailable in this container. Everything else in this document was executed.

---

## 14. Summary

One SQLite file, one `.npy` matrix, one Ollama process. Retrieval is numpy: brute-force similarity times a Thompson draw from each item's Beta posterior, pooled leave-one-out against its group, with Monte Carlo propensities logged for later off-policy evaluation — 1.83 ms end to end. Positive outcomes spread credit across everything retrieved; negatives spend sixty queued seconds finding one culprit, but only if judge calibration shows attribution accuracy above 0.35, because below that spreading blame scores better. Consolidation runs at 2am on AC power in model-batched chunks. Weekly SNIPS validates rules against natural retrieval variation, so no experiment is ever run on the user. Nothing writes to weights, nothing leaves the machine, and the one decision that makes it all work is hierarchical pooling — without it, ninety days of use moves precision from 0.20 to 0.28; with it, to 0.93 under ideal conditions and 0.39–0.55 under realistic ones — still roughly double the baseline, and the shadow A/B harness in §10 is the only thing that will tell you which you got.
