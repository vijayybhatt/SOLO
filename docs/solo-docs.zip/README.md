# SOLO Engine — Documentation Index

A self-learning memory system for AI. Fully local, offline, open-source.
Target: MacBook Air M5, Ollama, SQLite.

**Start here → `solo-local-implementation-validated.md`**

---

## The Files

### `solo-local-implementation-validated.md` — 24 KB ⭐
**The primary build document. Everything else supports this one.**

Schema, retrieval algorithm, model stack, timing, reward function, attribution, off-policy evaluation, build order, monitoring.

Every code path in it was executed and tested. Eight defects were found in the draft and fixed — the fix table is §0.

**Use it:** open on day one, keep it open until Phase 7 is done.

---

### `solo-prompts-and-ingest.md` — 20 KB
**The two things missing from the build doc.**

- **§1 Prompt library** — all five prompts (judge, topic detector, category classifier, extraction, LOO ranker) plus a parser that survives small-model output. Plain `json.loads` handles only 3 of 12 real outputs
- **§2 Ingest** — the write path. How facts get in, deduplication, contradiction handling, extraction caps

**Use it:** Phase 3 onward. You cannot build the reward layer without §1.

---

### `solo-config-and-runtime.md` — 16 KB
**Operational reference.**

- Every tunable parameter in one file, with a startup validator
- Cold-start behaviour — what happens in week 1 when the store is empty
- Application shell, request lifecycle, scheduling
- Failure modes — what SOLO does when Ollama dies

**Use it:** Phase 1 for the config, then whenever something breaks.

---

### `solo-engine-spec.md` — 15 KB
**Phase 0 decisions and why they were made.**

The reasoning behind facts-vs-rules, Beta scoring, Thompson Sampling, pessimistic priors, hierarchical pooling, protected memories, and the OPE choice.

**Use it:** read once for context. Return only when tempted to change a locked decision — the argument against is probably already in here.

---

### `solo-phase9-finetuning-validated.md` — 17 KB
**Month 6+. Making the model itself evolve.**

Data harvest from SOLO's own logs, fact-contamination controls, LoRA training on Apple Silicon, the promotion gate, adapter archive.

**Use it:** not now. But read §0 today — **two database columns must exist six months before you need them**, and they cannot be backfilled.

---

### `context-transfer.md` — 11 KB
**Session handoff.**

The full arc, locked decisions, every bug found during validation, current state, what's next. Written so a new session can resume without re-deriving anything.

**Use it:** when starting a fresh conversation about this project.

---

### `brain-notes.md` — 8 KB
**Background — the biology this is modelled on.**

Three brain layers, how memory filtering actually works, the robot analogy.

**Use it:** optional. Useful for explaining SOLO to someone else, or when a design choice stops making sense and you want the original intuition.

---

## Reading Order

**Building now:**
1. `README.md` — this file
2. `solo-engine-spec.md` — once, for context
3. `solo-local-implementation-validated.md` — the build
4. `solo-prompts-and-ingest.md` + `solo-config-and-runtime.md` — as each phase needs them

**Resuming later:** `context-transfer.md` first.

**Month 6:** `solo-phase9-finetuning-validated.md`.

---

## Do Not Use

These were superseded. They contain wrong stack advice (Postgres, pgvector, Graphiti) and the pre-fix reward scheme.

- `solo-engine-architecture.md` — cloud version
- `solo-engine-local-architecture.md` — replaced by the validated build doc
- `solo-engine-plan.md` — early research inventory

Delete them if any copies are still around.

---

## Three Things That Cannot Wait

**1. Three columns must be in your first migration.** None can be backfilled:

| Column | Needed by | Lost if missing |
|---|---|---|
| `propensity` | Off-policy evaluation | OPE impossible, permanently |
| `category` | Phase 9 contamination filter | 6 months of training data |
| `alt_absolute_score` | Phase 9 quality gate | 6 months of preference pairs |

**2. Four numbers must be calibrated, not guessed.** All marked ⚠️ in the config, each with a procedure:

- `SIM_DUP` / `SIM_RELATED` — 100 real embedding pairs
- `TOPIC_LOW` / `TOPIC_HIGH` — 50 hand-labelled message pairs
- Judge σ — 20 repeats on 30 samples
- LOO attribution accuracy — 40 hand-labelled failures

The last is a gate: **below 0.35, turn LOO off.** Measured, blame-all scores 0.51 against LOO's 0.43 at that accuracy.

**3. Hierarchical pooling is not optional.** 90-day simulation, precision@40, random baseline 0.20:

```
              day 30   day 60   day 90
no pooling     0.25     0.25     0.28   ← learns nothing
pooling        0.80     0.93     0.93   ← ideal conditions
```

**Realistic expectation is 0.39–0.55, not 0.93.** Once you account for the model (not memory) driving most answer quality, and realistic LOO attribution accuracy, precision lands at roughly double the baseline rather than five times it. Still worth building — but the shadow A/B harness is the only thing that tells you which number you actually got.

The median memory accumulates 4 observations in 90 days. Per-item statistics never converge at single-user volume. If anyone proposes simplifying this away, that table is the answer.

---

## What SOLO Is

**RAG with a feedback loop.** Not training.

Vanilla RAG ranks memories by similarity. SOLO ranks by `similarity × proven-usefulness`, where usefulness is a Beta distribution that moves every time you react to an answer.

The model never changes. What learns is **which memories surface and when**.

**The honest test:** run plain similarity retrieval alongside SOLO on the same queries, log both, and watch them diverge. If they never do, stop building.

---

## Validation Status

The full system was implemented and run end to end — 1,800 interactions across 90 simulated days, with a mock LLM and mock embeddings but everything else real.

- **0 crashes**, hot path **2.5 ms p50 / 5.1 ms p99**
- **26 defects found and fixed** across all validation passes
- **13 of them were only findable by executing code** — 2 needed a live Ollama server, 2 more surfaced only while writing the implementation
- The worst two: a failure handler that caught **zero** of the exceptions it was written for, and an outcome recorder that applied the same reward twice

**The working implementation is in `codebase.zip`** — 32 files, 96 tests, `DEFECTS.md` maps every defect to the test that prevents it.

The most dangerous class is silent corruption that looks healthy — eviction that never fires, scores that drift upward forever, a parser that turns `8` into a valid score. Those pass every dashboard.

---

## Build Estimate

| Phases | Deliverable | Time |
|---|---|---|
| 1–4 | Working loop — log, retrieval, rewards, pooling | ~4 weeks |
| 5–7 | Attribution, consolidation, validation | ~4 weeks |
| 9 | Fine-tuning | ~2 weeks, month 6+ |

Ship Phases 1–4, collect real data, then build the rest against measurements instead of assumptions.

**Expect months, not weeks, before the loop produces visible improvement.** Day 30 is the earliest anything is measurable. That's designed in, not a failure.
