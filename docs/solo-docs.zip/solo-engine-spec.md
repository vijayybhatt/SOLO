# SOLO Engine — Phase 0 Specification

A self-learning memory system for AI. Closed feedback loop, no weight updates.

**Status:** Phase 0 complete. All design decisions locked. Ready for architecture.

---

## 1. What SOLO Is

| Brain layer | AI equivalent | Status |
|---|---|---|
| Brainstem | Model guardrails — always on, never learns | Exists |
| Cortex | Reasoning + long-term storage | Exists |
| **Inner brain** | **SOLO** — the filtering layer | To build |

SOLO is the **write path and retrieval ranker**, not the warehouse.

### Component mapping

| Inner brain part | SOLO component | Scope |
|---|---|---|
| Thalamus | Routing / adaptive thinking | Build last — optimisation |
| Amygdala | Importance scorer | In scope |
| Hippocampus | Filter, consolidate, expire | **SOLO core** |
| Hypothalamus | Resource state | Deferred to robot phase |

### Design corrections baked in

1. **The hippocampus does not store long-term** — it filters, indexes, hands off. SOLO is not the database.
2. **Next-token scoring ≠ importance scoring** — but model confidence (logprobs) gives a free novelty signal.
3. **Memory ≠ self-learning** — the difference is the outcome loop. That loop is the whole product.

---

## 2. Core Principle

> Do not store everything. Store what changes future behaviour.

Two chokepoints do all the filtering, copied from biology:
- **Attention** at ingest — cheapest, harshest cut
- **Replay budget** at consolidation — only high-value items get promoted

---

## 3. Two Separate Systems

Facts and rules behave differently and get different machinery.

| | **Facts** | **Rules** |
|---|---|---|
| Example | "Daughter is named Anya" | "User prefers short answers" |
| Origin | Stated by user | Inferred by SOLO |
| Failure mode | Contradicted | Outvoted |
| Lifecycle | Versioned with timestamps | Beta distribution, can retire |
| Needs conditions? | No | Yes |
| Storage | Bi-temporal (valid_at / invalid_at) | Scored, context-clustered |

Both are **scored for retrieval ranking**. Only rules can be retired for poor performance.

---

## 4. Scoring — One Mechanism

Every memory and rule carries a **Beta distribution**, not a score.

```
Beta(α, β)   where α = accumulated successes, β = accumulated failures
```

This single object replaces all previously-considered thresholds:

| Discarded approach | Beta equivalent |
|---|---|
| 3 / 10 / 20 observation thresholds | The α+β total |
| "20 times in a row" | Unnecessary — 18 wins / 2 losses is a strong signal, no reset |
| 80% consistency ratio | The distribution mean |
| "Candidate vs trusted" | The distribution width |
| Reserved slots for new memories | Wide distribution = automatic exploration |

**No streaks. No resets. No arbitrary thresholds.**

### Retrieval = Thompson Sampling

- Sample a value from each candidate memory's Beta distribution
- Retrieve the top-k samples
- Proven memories → narrow, high → usually selected
- Untested memories → wide → occasionally selected, get their chance
- Failed memories → narrow, low → rarely selected

**Two properties this buys for free:**
1. **Cold start solved** — no reserved slots needed
2. **Delayed rewards tolerated** — stochastic policies keep exploring without updated rewards, and stay competitive as feedback delay grows

---

## 5. Cold Start — Pessimistic, but Reachable

**Decision: pessimistic initialisation.**

Rationale: an optimistic uniform prior implicitly assumes a 50% success rate for unseen items, which systematically over-allocates traffic to weak items when true base rates are lower.

**Prior: Beta(1, 9)** — starts at 10%.

| Successes | Score |
|---|---|
| Start | 10% |
| +10 | 55% |
| +20 | 70% |

**Why not Beta(1, 99):** production systems using that prior serve millions of interactions daily. At single-user volume, a 1% start never climbs out. Beta(1,9) is pessimistic and reachable.

---

## 6. Hierarchical Pooling — The Volume Fix

**Problem this solves:**

- ~20 interactions/day × 8 memories = 160 memory-uses/day
- 1,000-memory store → each memory used ~0.16 times/day
- ~40% of interactions yield a non-zero signal
- → **1 observation per memory per ~15 days → 300 days to reach 20 observations**

Without pooling, almost every distribution stays frozen and the loop learns nothing.

**Solution: partial pooling.** Each group's estimate becomes a weighted blend of its own raw mean and the overall grand mean — groups with little data are pulled strongly toward the grand mean, while data-rich groups keep their raw estimates. The degree of shrinkage is set automatically by the ratio of within-group to between-group variance.

### Implementation

1. Group memories by **type** — e.g. code preferences, personal facts, project context, communication style
2. Maintain a **group-level Beta** that accumulates observations from every member
3. New memories **inherit the group prior**, not the global prior
4. As a memory gathers its own evidence, it drifts away from the group

**Effect: ~300 days → ~30 days.**

Group definitions are a config file, revisable. Start with 4–6 groups.

---

## 7. Reward Function

Fed into Beta on every interaction.

| Event | Score | Notes |
|---|---|---|
| Explicit praise / thumbs up | **+1** | |
| Next message = new topic | **+0.5** | Previous request resolved |
| "Thanks" | **+0.3** | May be politeness only |
| Nothing, ambiguous | **0** | Skip, no update |
| User never returns | **0** | Rage-quit and satisfaction are indistinguishable |
| Follow-up question | **LLM judge decides** | Judge reads content, assigns +/− |
| Buggy code returned | **−1 to culprit** | Via targeted LOO |
| Explicit correction | **−1 to culprit** | Via targeted LOO |
| Next message = same problem again | **−1 to culprit** | Via targeted LOO |

**Notes:**
- Fractional updates are valid — Beta accepts +0.3
- Neutral is never treated as positive. Scores must be earned
- Silent use is **not** scored — indistinguishable from abandonment
- The "+0.5 moved on" signal replaces it, and requires a topic-change detector

**Required instrumentation:** topic-change detection on every turn (one cheap LLM call or an embedding-distance heuristic).

---

## 8. Credit Assignment

### Positive outcomes — cheap, split across contributors
- The reward is **divided** among all retrieved memories, not replicated to each
- Rationale: one good answer is worth **one** unit of credit. Giving each of 8 items the full reward while punishing 1 culprit produces a 10:1 upward drift — measured mean posterior climbs to 0.729 and eviction never fires
- Cost: zero extra calls

> **Corrected after validation.** The original design gave every retrieved item the full reward. See `solo-local-implementation-validated.md` §5 for the measurements and the fix.

### Negative outcomes — targeted leave-one-out
**Decision: Option C — targeted LOO on top 3.**

1. Rank retrieved memories by relevance to the specific error
2. Regenerate the answer without each of the top 3
3. The memory whose removal most improves the output is the culprit
4. **−1 to the culprit. 0 to everyone else.**

**Cost:** ~6 extra LLM calls per failure (3 regenerations + 3 judge calls).

**Why not full LOO:** 16 calls per failure, and when quality differences fall below the judge's noise floor the attribution is random.

**Why blame must be targeted:** a buggy answer may have used 6 correct memories and one bad one. Penalising all 7 corrupts the store fast.

---

## 9. Protected Memories

**Decision: permanence and retrieval ranking are independent.**

| | Protected | Normal |
|---|---|---|
| Can be deleted? | **Never** | Yes, if score collapses |
| Scored for retrieval timing? | **Yes** | Yes |

**What qualifies as protected:** defined by the seed rules — names, relationships, personal facts, dates, health. Self-evolving; SOLO can propose additions.

**Why the split matters:**
- "Daughter is named Anya" must survive two years of non-use → permanence
- But it must also learn to surface in family conversations and stay quiet during debugging → ranking
- Full exemption from scoring would create a blind spot: a protected memory surfacing at the wrong moment degrades answers with no correction path

---

## 10. Rule Validation — No A/B Testing

**Decision: off-policy evaluation (OPE) instead of deliberate withholding.**

Rejected: 1-in-100 A/B testing. At single-user volume it needs thousands of interactions per rule.

OPE estimates the performance of a decision policy from historical data generated by a different policy, without costly online A/B tests. In production at Adyen, IPS and SNIPS estimators held above 0.8 correlation with actual online A/B results.

**Why it works here:** rules already fire inconsistently in normal use — different memories retrieved, different contexts. That natural variation *is* the experiment.

### ⚠️ Hard precondition

IPS requires a **stochastic** logging policy — the system must draw from a probability distribution rather than always serving its top pick. Under fully deterministic logging, these estimators cannot evaluate under-explored actions at all.

**Thompson Sampling satisfies this automatically.** But:

> **You must log the sampled propensity — the probability — for every retrieved memory, at retrieval time.**

Not the score. The probability. It cannot be reconstructed later. Skipping this makes OPE permanently impossible on that data.

---

## 11. Context Handling

**Decision: automatic discovery, not user-declared.**

Users will not volunteer conditions ("I prefer short answers *when rushed*"). They don't know that about themselves.

- Use **latent context clustering** — contextual bandit frameworks handle hidden factors that shape feedback without being directly observed
- Combining unsupervised online clustering with contextual bandits lets the system learn context representations even when reward feedback is missing
- A memory that helps in cluster A and hurts in cluster B gets split automatically

**Escape hatch:** when a rule sits near 50% consistency, that signals a hidden condition. SOLO may ask the user directly: *"You sometimes want short answers and sometimes detailed ones — is there a pattern?"* Rate-limited.

---

## 12. THE FOUNDATION — Build This First

> **Log which memories and rules were active on every interaction, with their sampled propensities, paired with whatever outcome signal arrived.**

Required by:
- Thompson Sampling — needs outcomes per memory
- OPE — needs propensities; logged data is otherwise biased toward the logging policy's preferences
- Leave-one-out — needs the retrieval set
- Context clustering — needs the full interaction record
- Hierarchical pooling — needs group membership

**No log, no learning loop.** Unglamorous, non-negotiable, first.

### Minimum log schema

```
interaction_id
timestamp
user_input
retrieved_items[]      → { item_id, type, group, sampled_propensity, rank }
response
outcome_signal         → { raw_event, score, judge_reasoning }
attribution            → { culprit_id, loo_deltas } | null
context_cluster_id
```

---

## 13. Phased Roadmap

| Phase | Build | Source |
|---|---|---|
| **1** | Interaction log with propensities | Foundation — build first |
| **2** | Memory object schemas (facts + rules) | Design |
| **3** | Ingest filter + importance scorer | ExpeL-style |
| **4** | Beta scoring + Thompson Sampling retrieval | Standard bandits |
| **5** | Reward function + topic-change detector | Custom |
| **6** | Hierarchical pooling by group | Standard hierarchical Bayes |
| **7** | Targeted LOO on failures | AttriBoT-style |
| **8** | Background consolidation → rules | Sleep-time compute |
| **9** | Bi-temporal fact store | Two timestamp columns in SQLite — **not** a graph DB |
| **10** | OPE-based rule validation | IPS / SNIPS |
| **11** | Latent context clustering | Contextual bandits |
| **12** | Router / adaptive thinking | Last — optimisation |

---

## 14. Explicitly Out of Scope

**Writing to weights.** Continual fine-tuning causes catastrophic forgetting; the state of the art still degrades on earlier tasks as self-edits accumulate, is slow, and needs a fine-tune plus eval per edit.

Every working system — Voyager, Reflexion, Generative Agents, Mem0, Zep, Memory-R1 — succeeds without touching weights.

**Decision: retrieval-into-context is the storage mechanism. Closed as won't-fix.**

Also deferred:
- Hypothalamus equivalent (resource/battery state) — robot phase
- Self-modifying code — not applicable, unnecessary risk

---

## 15. Known Risks

| Risk | Mitigation |
|---|---|
| Judge noise swamps LOO deltas | Targeted LOO limits exposure; log deltas and audit |
| Topic-change detector is unreliable | +0.5 is the main positive signal — validate it early |
| Protected category swallows most of the store | Permanence/ranking split contains this; monitor the ratio |
| Group definitions are wrong | Config-driven, revisable; watch for groups with high internal variance |
| Negatives outnumber positives → store decays | Monitor the ratio; retune reward weights if drift appears |
| Very recent techniques (LRE, Memory Worth, D-MEM) unreplicated | Treat as optional enhancements, not dependencies |

---

## 16. What Makes SOLO Novel

Not the storage — that's commodity.

> **Memories and rules carrying a confidence distribution that rises and falls based on whether using them actually worked, validated without running experiments on the user.**

The two genuine inventions:
1. **Outcome-driven scoring in a non-verifiable domain** — no test suite, no code executor, only weak behavioural signals
2. **OPE-based rule validation for personal memory** — not published for this use case

Everything else is integration of published components.

---

## 17. The Verifiability Gap — Read Before Building

DGM, AlphaEvolve, AZR, and SEAL work because code and math give a **free, automatic correctness oracle**. That oracle is what makes their credit assignment tractable.

SOLO has no oracle. Preferences, relationships, and episodic detail are not cheaply checkable.

**Consequences, designed for from day one:**
- The reward signal is weak, delayed, and noisy → rely on statistical accumulation, never a single event
- Hierarchical pooling is not optional — it's what makes weak signals usable at low volume
- OPE substitutes for the missing oracle
- Expect months, not days, before the loop produces visible improvement
