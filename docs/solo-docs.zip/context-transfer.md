# SOLO Engine — Context Transfer

Complete handoff for resuming this work in a new session.

**Covers:** brain anatomy study → AI memory architecture → validated local implementation specs.

---

## 1. How to Work With Me (Read First)

Preferences established over this conversation. Following them saves a lot of correction.

- **Short, point-wise answers.** Bullets over paragraphs. 1–5 lines per point
- **No jargon** unless asked. Plain words first, technical terms only when they earn their place
- **Always tag the brain layer** — say "cortex," "inner brain," or "brainstem" when naming any part
- **No diagrams unless I explicitly ask.** This was requested directly
- **Don't soften bad news.** If a plan is broken, say so and show the numbers
- **Validate before shipping.** I will ask for `L99` — install and test everything you can in your container, find blindspots, fix them, then give me the doc
- **Correct yourself openly.** Several of your earlier claims were wrong. Flagging them was more useful than defending them

---

## 2. The Arc

### Part 1 — Brain anatomy (self-study)

Started as general curiosity, big-picture level. Learned:

- **Three layers:** brainstem (survival), inner brain (emotion + filtering), cortex (thinking + storage)
- **Brainstem** = background service. Runs from birth, never learns, stores nothing
- **Inner brain** = thalamus (router), amygdala (alarm), hippocampus (filter), hypothalamus (body state)
- **Cortex** = four lobes; does the thinking **and** holds long-term memories

**Key corrections made along the way:**

1. The hippocampus is **not a save button — it's a filter.** It indexes and hands off; the cortex stores
2. Nobody remembers everything. HSAM exists but fewer than 100 identified cases worldwide, and only for personal life events
3. What survives: attention → emotion → novelty → repetition, then sleep commits the winners
4. The ear is the input, the thalamus is the post office, the temporal lobe (cortex) is where sound gets understood

**Best analogy from this section:** memory isn't a recording, it's a **rule-builder**. It keeps only what changes your future behaviour. The robot-in-a-new-house example landed well.

### Part 2 — Mapping to AI

Your proposal, which held up:

| Brain | AI |
|---|---|
| Brainstem | Model guardrails — always on, never learns |
| Cortex | Reasoning + long-term storage |
| **Inner brain** | **Missing. This is SOLO.** |

Named the project **SOLO engine**.

### Part 3 — Research

Investigated five self-improving systems (DGM, AlphaEvolve, SEAL, AZR, MiniMax M2.7).

**Verdict: mostly not useful.** All five depend on a free correctness oracle — a test suite or code executor. A personal memory system has none. MiniMax's "self-evolution" is marketing.

**What was actually borrowable:**
- **DGM's append-only archive** — never overwrite, so a bad change can't destroy a good ancestor
- **ExpeL's vote-counted rules** — start at 2, upvote/downvote, auto-retire at 0
- **Leave-one-out attribution** — measure a memory's marginal contribution
- **The universal pattern** — measure before you keep

**The reframe that unlocked everything:** the problem is **contextual bandits**, a solved 60-year-old field. Most of the "unsolved" gaps were textbook.

### Part 4 — Design, validation, documentation

Phase 0 decisions locked, then architecture, then a local MacBook M5 version, then validation passes that found real bugs.

---

## 3. Locked Decisions (Do Not Relitigate)

| Decision | Choice | Why |
|---|---|---|
| Facts vs rules | **Two separate systems** | Different lifecycles — facts get contradicted, rules get outvoted |
| Scoring | **Beta distribution per item** | Replaces all thresholds; width = confidence |
| Prior | **Beta(1, 9)** = 0.10 | Beta(1,99) never climbs out at single-user volume |
| Retrieval | **Thompson Sampling** × similarity | Solves cold start, tolerates delayed rewards, gives OPE its propensities free |
| **Pooling** | **Hierarchical, leave-one-out** | **The single most important decision.** See §4 |
| Blame | Spread positives, targeted LOO on failures | Precision only matters for negatives |
| LOO | **Top-3 by relevance**, not all 8 | Bounded cost |
| Protected items | **Permanence and ranking are independent** | Anya's name never deleted, but still learns *when* to appear |
| Rule validation | **Off-policy evaluation (SNIPS)**, not A/B | Never experiment on the user |
| Weight updates | **Deferred to Phase 9**, retrieval-into-context until then | SEAL still shows catastrophic forgetting |
| Storage | **SQLite + numpy `.npy`** | See §5 |

### The reward table

| Event | Score |
|---|---|
| Explicit praise | +1.0 |
| Next message = new topic | +0.5 |
| "Thanks" | +0.3 |
| Nothing / ambiguous | 0 |
| Never returns | 0 |
| Follow-up | judge decides |
| Failure | −1.0 to culprit |

**Silent use is scored 0** — your call, and correct. Rage-quit and satisfaction are indistinguishable.

---

## 4. The Result That Justifies Everything

90-day simulation, 200 memories of which 40 are genuinely useful. Random baseline = 0.20.

```
              day 30   day 60   day 90
no pooling     0.25     0.25     0.28   ← learns nothing
pooling        0.80     0.93     0.93
```

**Why:** after 90 days the median memory has **4 observations**. Only 39 of 200 reach 20. Per-item statistics never converge at single-user volume.

**If anyone proposes dropping hierarchical pooling, this is the answer.**

**Caveat added after red teaming:** 0.93 assumes memory selection drives answer quality. It mostly doesn't — the model does. With realistic memory weight and LOO accuracy, expect **0.39–0.55**. Still ~2× baseline. The shadow A/B harness (Phase 1.5) is the only way to know which you got.

---

## 5. Bugs Found During Validation

Every one was found by executing code, not by reasoning. Do not reintroduce them.

### In the architecture

| Bug | Symptom |
|---|---|
| `superseded_by = -1` soft delete | `FOREIGN KEY constraint failed` → use a `deleted_at` column |
| `Beta(0, x)` when φ hits 0 or 1 | `ValueError: a <= 0` → clamp φ to [0.02, 0.98] |
| sqlite-vec | Apple disables extension loading in system SQLite; **also 6–9× slower than numpy**. Dropped entirely |
| Propensity floor 1e-3 | 1000× IPS weights → floor at 1e-2, exclude <0.05 from OPE |
| Pooling used raw group sums | Item inflated its own prior → leave-one-out group stats |
| **Full reward to each retrieved item** | **10:1 upward drift.** Mean posterior hits 0.729 and climbs, eviction never fires → **split the reward by K** |
| Absolute eviction threshold 0.15 | Evicts 33% of the store after the reward fix → percentile-based |

### In the prompts and ingest

| Bug | Symptom |
|---|---|
| `json.loads` on model output | Handles **3 of 12** real outputs. `{"score": 8}` → `8.0` on a 0–1 scale, silent corruption |
| Dedup checked before contradiction | "Ananya, not Anya" classified as duplicate and **silently dropped** |
| Unbounded extraction | 12 facts from one turn; 29,200 items/year vs 6,570 capped |
| No LLM fallbacks | Ollama down/timeout/OOM crashes the app |

### Found while building the implementation

| Bug | Symptom |
|---|---|
| **`record_outcome` not idempotent** | Scoring the same interaction twice applied the reward twice (alpha rose 2.5x). Auto-scoring also overwrote 9 of 10 manual scores. Guard on `scored_at` |
| Health check false-healthy | `guarded()` returned `[]` as its fallback and `[] is not None`, so an unreachable server reported OK. Fallbacks must be distinguishable from real results |

### Found only by running against a live Ollama server

| Bug | Symptom |
|---|---|
| **`guarded()` caught nothing** | `openai` raises `NotFoundError` / `APIConnectionError` / `APITimeoutError`, none of which inherit from builtin `ConnectionError`. **Every Ollama failure would crash the chat.** Catch the `openai.APIError` family |
| `/v1/models` returns `data: null` | `for m in resp.data` → `TypeError`. Iterate `resp` instead |

### Found only by building and running it

| Bug | Symptom |
|---|---|
| **Decay caps evidence below the eviction threshold** | `equilibrium_obs = daily_gain/(1−DECAY)` ≈ 15 at DECAY=0.990, but threshold was 20. **0/96 items ever qualified.** Eviction silently never fired |
| `Σ propensity ≈ 8` ambiguous | True over all candidates; 2–6 over the chosen subset. Monitoring would false-alarm constantly |
| Decay mischaracterised | It preserves the mean and shrinks confidence — makes scores *correctable*, doesn't correct them |
| `moved_on` fired ~every turn | 7.7:1 over `thanks`. `+0.5` became a participation trophy |
| Group regex matched the word, not the pattern | `raj@example.com` filed as `episodic` instead of `personal` |

### In Phase 9

| Bug | Symptom |
|---|---|
| **Stock mlx-lm has no DPO** | No `chosen`/`rejected` support. Plan changed to rejection-sampling SFT |
| `pip install mlx` on x86 | **Exits 0, binary broken.** Never trust the exit code |
| Keyword fact-scrubbing | Rejects 50% of good data *and* misses every paraphrase |
| N=50 eval | Only 0.36 power to detect +0.05 → need 150 |
| Testing 4 metrics | 19% false-positive rate → one pre-declared primary metric |

---

## 6. Document Map

| File | Purpose |
|---|---|
| `solo-engine-spec.md` | Phase 0 decisions and rationale |
| **`solo-local-implementation-validated.md`** | **Primary build doc** |
| `solo-prompts-and-ingest.md` | Five prompts + robust parser + write path |
| `solo-config-and-runtime.md` | Config, cold start, app shell, failure modes |
| `solo-phase9-finetuning-validated.md` | Month 6+, LoRA |
| `brain-notes.md` | Background — the anatomy study |
| ~~`solo-engine-architecture.md`~~ | Cloud version — **delete** |
| ~~`solo-engine-local-architecture.md`~~ | Superseded — **delete** |

---

## 7. Current State

**Design and documentation: complete.** Nothing blocking a build.

### Target environment

- MacBook Air M5, fully offline
- 153 GB/s bandwidth — this sets speed, not RAM
- **16 GB: run one model for everything.** 24 GB comfortable, 32 GB unlocks Qwen 3.6-35B-A3B
- Ollama + Gemma 4 12B + BGE-small-en-v1.5
- SQLite (WAL) + `embeddings.npy`

### Measured performance

- Hot path: **16 ms** pre-LLM
- Retrieval: 1.83 ms at 50 candidates
- Concurrency: 1 writer + 2 readers, 900 ops, 0 errors
- ~9.5 min/day total compute
- Store growth: ~6,570 items/year capped and deduped

---

## 8. What's Next

### Build Phases 1–4 first — about four weeks

1. Schema + interaction log **with propensities**
2. Retrieval — numpy similarity + pooled Thompson + MC propensity
3. Reward — topic detector + score application
4. Group stats with leave-one-out pooling

That's a working loop. Then return with real data before building 5–7.

### Four numbers that must be calibrated, not guessed

| Parameter | How |
|---|---|
| `SIM_DUP` / `SIM_RELATED` | 100 real BGE-small pairs |
| `TOPIC_LOW` / `TOPIC_HIGH` | 50 hand-labelled message pairs |
| Judge σ | 20 repeats on 30 samples |
| LOO attribution accuracy | 40 hand-labelled failures |

**The last one is a gate.** Below 0.35 accuracy, LOO scores 0.43 while blame-all scores 0.51 — turn LOO off and save 60 seconds per failure.

### Three columns that cannot be backfilled

Get these in the first migration or lose six months:

- `propensity` — Thompson probability at retrieval time. OPE is impossible without it
- `category` — Phase 9's contamination whitelist
- `alt_absolute_score` — Phase 9's quality gate on LOO winners

---

## 9. Framing

**SOLO is RAG with a feedback loop.** Not training.

- The model never changes (until Phase 9, and even then only style)
- What learns is the **retrieval policy** — which memories surface and when
- **Fine-tune the *how*, retrieve the *what*.** Facts must never go in weights; you can't `UPDATE` a weight

**What makes it novel:** memories carrying a confidence distribution that rises and falls based on whether using them actually worked, validated without running experiments on the user. Nobody ships that.

**The honest test:** does it beat plain similarity-ranked RAG on your real data? Run both, log both, watch them diverge. If they never do, stop building.

---

## 10. Resuming

Say something like:

> "Continuing the SOLO engine build. Context is in `context-transfer.md`. I've built Phases 1–N. Here's what the data shows: [numbers]."

Then work from `solo-local-implementation-validated.md` as the primary reference.

**Expect months, not weeks, before the loop produces visible improvement.** The pooling result in §4 shows day 30 as the earliest point where anything is measurable. That's designed-in, not a failure.
