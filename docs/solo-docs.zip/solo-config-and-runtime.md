# SOLO Engine — Config & Runtime (Validated)

Consolidated parameters, cold-start behaviour, application shell, failure modes.

Companion to `solo-local-implementation-validated.md` and `solo-prompts-and-ingest.md`.

---

## 0. Validation Summary

| # | Finding | Fix |
|---|---|---|
| 1 | κ = 10 requires **~10 observations** to move an item 0.40 → 0.60 | Correct; κ > 25 makes the group drown the individual |
| 2 | Absolute eviction threshold evicts **33% of the store** after the reward fix | Percentile-based |
| 3 | Every LLM call fails 3 ways; none had a fallback | Degrade to plain retrieval, never crash |
| 4 | Thompson Sampling is **inert until day 7–14** | Cold-start ladder |
| 5 | Hot path measured at **16 ms** pre-LLM | Confirmed under the 50 ms budget |
| 6 | 1 writer + 2 readers, 900 ops: **0 errors** in 0.49 s under WAL | Concurrency validated |

---

# §1 — Configuration

One file. Every tunable in the system. Values marked ⚠️ must be calibrated on your data.

```python
# solo/config.py

# ── Scoring ────────────────────────────────────────────────
KAPPA          = 10.0    # pooling strength, in equivalent observations
PRIOR_A        = 1.0     # global prior Beta(1,9) → 0.10, pessimistic
PRIOR_B        = 9.0
PHI_MIN        = 0.02    # clamp: outside this, numpy raises ValueError
PHI_MAX        = 0.98
DECAY          = 0.990   # nightly evidence discount, ~70-day half-life
                         # without it, Beta(50,10) needs 40 straight failures to fall below 0.50

# ── Retrieval ──────────────────────────────────────────────
N_CANDIDATE    = 50
N_RETRIEVE     = 8
N_MC           = 500     # Monte Carlo draws for propensity
PROP_FLOOR     = 1e-2    # 1e-3 produced 1000x IPS weights
EMBED_DIM      = 384     # BGE-small-en-v1.5

# ── Rewards ────────────────────────────────────────────────
R_POSITIVE     = +1.0
R_MOVED_ON     = +0.5
R_THANKS       = +0.3
R_FAILURE      = -1.0
SPLIT_POSITIVE = True    # ⚠️ MANDATORY — see implementation doc §5

# ── Attribution ────────────────────────────────────────────
LOO_ENABLED    = None    # ⚠️ set by calibration; None until measured
LOO_K          = 3
LOO_QUEUE_MAX  = 20
NOISE_FLOOR    = None    # ⚠️ = 1.5 × measured judge sigma
LOO_MIN_ACC    = 0.35    # below this, disable LOO entirely
BLAME_ALL      = -0.3    # fallback penalty when LOO is off or overflowing

# ── Ingest ─────────────────────────────────────────────────
SIM_DUP        = 0.95    # ⚠️ calibrate on 100 real BGE-small pairs
SIM_RELATED    = 0.82    # ⚠️ must be < SIM_DUP
EXTRACT_CAP    = 5
RULE_CAP       = 3
EXPLICIT_SLA   = 60      # seconds

# ── Eviction ───────────────────────────────────────────────
EVICT_MIN_OBS  = 20
EVICT_RATIO    = 0.5     # evict below 0.5 × store mean, NOT an absolute
EVICT_UNUSED_D = 90

# ── OPE ────────────────────────────────────────────────────
OPE_MIN_PROP   = 0.05    # exclude below this; do not floor
OPE_MIN_ROWS   = 30

# ── Detection ──────────────────────────────────────────────
TOPIC_LOW      = 0.35    # ⚠️ calibrate on 50 labelled pairs
TOPIC_HIGH     = 0.60

# ── Models ─────────────────────────────────────────────────
BASE_URL       = "http://localhost:11434/v1"   # never hard-code elsewhere
MODEL_MAIN     = "gemma4:12b"
MODEL_SMALL    = "gemma4:e2b"                  # = MODEL_MAIN on 16 GB
MODEL_EMBED    = "bge-small-en-v1.5"
LLM_TIMEOUT_S  = 30
```

## 1.1 Validate the config at startup

Seven cross-checks. All pass on the values above.

```python
def validate_config(c):
    errs = []
    if c.N_RETRIEVE > c.N_CANDIDATE:      errs.append("N_RETRIEVE > N_CANDIDATE")
    if c.PROP_FLOOR >= c.OPE_MIN_PROP:    errs.append("PROP_FLOOR must be < OPE_MIN_PROP")
    if c.SIM_RELATED >= c.SIM_DUP:        errs.append("SIM_RELATED must be < SIM_DUP")
    if c.KAPPA > 25:                      errs.append("KAPPA too high: group drowns individual")
    if 1 / c.PROP_FLOOR > 200:            errs.append("max IPS weight too high")
    if c.LOO_K > c.N_RETRIEVE:            errs.append("LOO_K > N_RETRIEVE")
    if c.PRIOR_A / (c.PRIOR_A + c.PRIOR_B) > 0.25:
                                          errs.append("prior not pessimistic")
    if not (0.95 <= c.DECAY <= 1.0):      errs.append("DECAY outside [0.95, 1.0]")
    if c.DECAY < 0.97:                    errs.append("DECAY too aggressive: discards real signal")
    if errs:
        raise ValueError("config incoherent: " + "; ".join(errs))
```

Run it on boot. A silently incoherent config produces a system that looks like it works.

## 1.2 Why κ = 10

Measured — observations needed to move an item from its group mean of 0.40 to 0.60:

| κ | one +0.5 moves mean by | observations to 0.60 |
|---|---|---|
| 2 | 0.1200 | 2 |
| 5 | 0.0545 | 5 |
| **10** ✅ | **0.0286** | **10** |
| 20 | 0.0146 | 20 |
| 50 | 0.0059 | 50 |

- **κ too low** → pooling stops helping, you're back to per-item statistics that never converge
- **κ too high** → the group drowns the individual; every item in a group scores the same

At ~1 observation per item per 15 days, κ = 10 means roughly 5 months for an item to fully differentiate — with the group carrying it from day one. That's the trade the whole architecture is built on.

**Tuning:** items never differentiating from their group → lower κ. New items behaving erratically → raise it.

---

# §2 — Cold Start

## 2.1 What actually happens

Simulated, capped-and-deduped ingest at ~0.9 items/interaction:

| Day | Items | Retrieval | State |
|---|---|---|---|
| 1 | 15 | 8 of 15 | All untested, prior-driven |
| 3 | 57 | 8 of 57 | All untested, prior-driven |
| 7 | 121 | 8 of 121 | Some evidence |
| 14 | 248 | 8 of 248 | Some evidence |

**Days 1–3: Thompson Sampling does nothing.** Every item has identical priors, so selection is effectively similarity-ranked with noise. That's fine — it's a plain RAG system, which is a reasonable baseline.

**The loop starts mattering around day 7–14.** Set expectations accordingly.

## 2.2 The seed rules

From Phase 0, these bootstrap the protected category before any learning:

```python
SEED_RULES = [
    "Remember all names of people the user mentions",
    "Remember all stated relationships",
    "Remember anything the user says more than twice",
    "Remember explicit corrections permanently",
]
```

These are **ingest instructions**, not scored rules. They shape what gets stored on day 1, when there's nothing to score.

## 2.3 The ladder

| Phase | Days | Behaviour |
|---|---|---|
| **Bootstrap** | 1–7 | Similarity-only retrieval. Log everything. No eviction, no OPE |
| **Warming** | 8–30 | Thompson active. Groups accumulating. Still no eviction |
| **Active** | 31–90 | Full loop. Eviction enabled. OPE begins reporting |
| **Mature** | 90+ | Rule extraction meaningful. Phase 9 harvest viable |

```python
def stage(day):
    if day <= 7:  return dict(thompson=False, evict=False, ope=False, rules=False)
    if day <= 30: return dict(thompson=True,  evict=False, ope=False, rules=False)
    if day <= 90: return dict(thompson=True,  evict=True,  ope=True,  rules=False)
    return              dict(thompson=True,  evict=True,  ope=True,  rules=True)
```

**Eviction stays off until day 31.** Before then, low scores mean "untested," not "bad" — and evicting untested items destroys exactly the memories that never got a chance.

## 2.4 What the user should be told

Week 1 will feel like a normal assistant, because it is one. Say so.

- Don't promise personalisation on day 1
- Do surface **what it has learned** — a simple "SOLO knows 47 things about you" builds trust while the loop warms up
- Corrections should feel instant even though extraction is nightly (the `EXPLICIT_SLA` path in the ingest doc §2.3)

---

# §3 — Application Shell

## 3.1 SOLO is a library, not a proxy

```
┌──────────────┐
│   Your UI    │
└──────┬───────┘
       │ chat(user_input, session_id)
┌──────▼───────────────────────────────────┐
│ SOLO                                     │
│  retrieve → build context → call model   │
│  → log → schedule follow-ups             │
└──────┬─────────────────────┬─────────────┘
       │                     │
┌──────▼──────┐       ┌──────▼──────┐
│   Ollama    │       │  solo.db    │
│  :11434/v1  │       │ + .npy      │
└─────────────┘       └─────────────┘
```

**A library, not a proxy.** SOLO needs to know when the user's *next* message arrives to compute the `+0.5` signal. A stateless proxy can't do that.

## 3.2 Request lifecycle

```python
def chat(user_input, session_id):
    t0 = time.perf_counter()

    q_vec = embed(user_input)                                    #  8 ms

    prev = last_interaction(session_id)
    if prev and prev.outcome_score is None:
        schedule(score_previous, prev.id, q_vec, user_input)     # +0.5 path

    items, sims, thetas, props = retrieve(q_vec)                 #  5 ms
    context = build_context(items)                               #  1 ms

    iid = log_interaction(user_input, q_vec, items, sims,        #  2 ms
                          thetas, props)
    assert (time.perf_counter() - t0) < 0.05                     # 16 ms measured

    response = llm(context + user_input)                         # streams

    log_response(iid, response)
    schedule(classify_category, iid)
    schedule(detect_outcome, iid)
    return response
```

**Measured hot-path budget:**

| Step | ms |
|---|---|
| Embed query (BGE-small) | 8 |
| numpy similarity, 20k items | 2 |
| Thompson + propensity | 2 |
| SQLite metadata fetch | 1 |
| Build context | 1 |
| Log write | 2 |
| **Total pre-LLM** | **16** |

Comfortably under the 50 ms budget, with room for the store to grow 5×.

## 3.3 Scheduling

```python
from apscheduler.schedulers.background import BackgroundScheduler

sched = BackgroundScheduler()
sched.add_job(drain_loo_queue,  'interval', minutes=5,  id='loo')
sched.add_job(nightly_batch,    'cron', hour=2,  id='nightly')
sched.add_job(weekly_ope,       'cron', day_of_week='sun', hour=3, id='ope')
sched.start()
```

Gate the heavy jobs on power:

```python
import subprocess

def on_ac_power():
    try:
        out = subprocess.run(["pmset","-g","ps"], capture_output=True,
                             text=True, timeout=5).stdout
        return "AC Power" in out
    except Exception:
        return True          # fail open — better to run than never run

def nightly_batch():
    if not on_ac_power():
        log.info("nightly skipped: on battery"); return
    for chunk in chunks_of(work, minutes=2):
        chunk.run(); time.sleep(30)      # thermal pacing, fanless chassis
```

**`on_ac_power` fails open.** If `pmset` breaks, running the job on battery once is better than never consolidating again.

## 3.4 Failure modes

Tested three ways Ollama dies. Every one must have a fallback.

| Failure | Exception | SOLO's response |
|---|---|---|
| Ollama not running | `openai.APIConnectionError` | Degrade to similarity-only retrieval |
| Model slow / hung | `openai.APITimeoutError` | Skip the optional call, log, continue |
| Model not pulled | `openai.NotFoundError` | **Most common on day one.** Fall back, log loudly |
| Out of memory | `openai.APIStatusError` (500) | Fall back to `MODEL_SMALL`; if that fails, skip |
| DB locked | `OperationalError` | Retry with backoff (5 s timeout, WAL) |
| `embeddings.npy` missing | `FileNotFoundError` | Rebuild from SQLite, warn |
| Adapter/base mismatch | — | Refuse to load, use base model |

> ### 🔴 Critical — the obvious `guarded()` catches nothing
>
> Tested against a **live Ollama server**. The `openai` client does **not** raise Python builtins:
>
> | Failure | Exception raised | MRO |
> |---|---|---|
> | Model not pulled | `NotFoundError` | ← `APIStatusError` ← `APIError` ← `OpenAIError` |
> | Server down | `APIConnectionError` | ← `APIError` ← `OpenAIError` ← `Exception` |
> | Host unroutable | `APITimeoutError` | ← `APIError` ← `OpenAIError` |
>
> **`openai.OpenAIError` inherits directly from `Exception`.** It is not a `ConnectionError`, not a `TimeoutError`, not an `OSError`.
>
> A handler written as `except (ConnectionError, TimeoutError, RuntimeError)` catches **zero** of these. Every Ollama failure would propagate and crash the chat — the exact outcome the fallback exists to prevent.

```python
import openai

# Verified: 5/5 real failure modes caught against a live Ollama server.
LLM_ERRORS = (
    openai.APIConnectionError,   # server down / refused
    openai.APITimeoutError,      # hung or unroutable
    openai.APIStatusError,       # 4xx/5xx incl. NotFoundError (model not pulled)
    openai.APIError,             # parent of the above
    openai.OpenAIError,          # anything else from the client
    ConnectionError, TimeoutError, OSError, RuntimeError,   # non-client transport
)

def guarded(fn, fallback, label="llm"):
    try:
        return fn()
    except LLM_ERRORS as e:
        log.warning("%s degraded: %s", label, type(e).__name__)
        return fallback
    except Exception as e:
        log.error("%s UNEXPECTED: %s", label, type(e).__name__)
        raise                      # never silently swallow a real bug
```

**Do not narrow this list.** `NotFoundError` in particular is the one you hit on day one, before any model is pulled.

**The governing rule:** every SOLO component is optional except retrieval and logging. If the judge dies, outcomes go unscored — the loop slows but nothing corrupts. If Ollama dies entirely, SOLO still returns memories; the app just has no model to call.

**Never let a SOLO failure crash the chat.**

## 3.5 Concurrency

Tested: 1 writer + 2 readers, 300 operations each under WAL.

```
0 errors in 0.49 s
```

```python
def connect(path):
    db = sqlite3.connect(path, timeout=5.0)
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA foreign_keys=ON")
    db.execute("PRAGMA synchronous=NORMAL")
    return db
```

**One connection per thread.** SQLite connections are not thread-safe. The scheduler, the hot path, and the LOO drainer each open their own.

## 3.6 Layout

```
solo/
  config.py           # §1, validated on boot
  db.py               # connections, schema, migrations
  embed.py            # BGE-small + the .npy matrix
  retrieve.py         # Thompson + propensity
  reward.py           # outcome detection, score application
  attribute.py        # LOO queue and drain
  ingest.py           # write path
  consolidate.py      # nightly
  ope.py              # weekly SNIPS
  prompts/            # versioned, one file each
  llm.py              # guarded client, ALL calls route through here
data/
  solo.db
  embeddings.npy
  adapters/           # Phase 9
```

> ### ⚠️ `/v1/models` returns `data: null`, not `[]`
>
> Verified against Ollama 0.5.7 with no models installed: `{"object":"list","data":null}`.
>
> - `for m in resp.data:` → **`TypeError: 'NoneType' is not iterable`**
> - `for m in resp:` → safe, yields nothing
>
> Your startup health check is the first thing that hits this.

> ### WARNING: `guarded()` fallbacks must be distinguishable from success
>
> A health check written as `models = guarded(list_models, [])` reports an
> **unreachable server as healthy**, because `[] is not None` — and an empty list
> is also what a reachable-but-empty server legitimately returns.
>
> ```python
> def available_models(self):
>     # None = unreachable.  [] = reachable, no models installed.
>     return guarded(lambda: [m.id for m in self.client.models.list()], None)
> ```
>
> Pick a fallback that cannot be confused with a real result. This applies to
> every `guarded()` call site, not just this one.

**Every model call goes through `llm.py`.** One place for timeouts, fallbacks, retries, and the base URL — which stays configurable so you can route the judge to a frontier model if calibration demands it.

---

# §4 — Pre-Flight Checklist

Before Phase 1:

- [ ] `python -c "import mlx.core"` — Phase 9 only, but check the machine now
- [ ] `curl localhost:11434/v1/models` returns
- [ ] `validate_config()` passes
- [ ] WAL enabled, verified with `PRAGMA journal_mode`
- [ ] `propensity` column is `NOT NULL` — it cannot be backfilled
- [ ] `category` column exists (Phase 9 needs six months of it)
- [ ] `alt_absolute_score` column exists (same reason)
- [ ] Every LLM call routed through `llm.py` with a fallback
- [ ] `BASE_URL` read from config, never hard-coded

Calibrate in Phase 1–3, before trusting anything downstream:

- [ ] `SIM_DUP` / `SIM_RELATED` on 100 real embedding pairs
- [ ] `TOPIC_LOW` / `TOPIC_HIGH` on 50 hand-labelled message pairs
- [ ] Judge σ — 20 repeats on 30 samples
- [ ] LOO attribution accuracy on 40 hand-labelled failures → sets `LOO_ENABLED`

---

# §5 — Document Map

| Document | Purpose |
|---|---|
| `solo-engine-spec.md` | Phase 0 decisions and rationale |
| **`solo-local-implementation-validated.md`** | **Primary build doc** |
| `solo-prompts-and-ingest.md` | Prompts + write path |
| **`solo-config-and-runtime.md`** | This — config, cold start, shell |
| `solo-phase9-finetuning-validated.md` | Month 6+ |
| ~~`solo-engine-architecture.md`~~ | Cloud — **delete** |
| ~~`solo-engine-local-architecture.md`~~ | Superseded — **delete** |

**Build order:** read the spec once for context, then work from the implementation doc, reaching into prompts/ingest and this one as each phase needs them.
