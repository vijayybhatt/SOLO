# SOLO Engine — Phase 9: Local Fine-Tuning (Validated)

Making the model itself evolve. MacBook Air M5 · fully offline · open-source.

**Prerequisite: Phases 1–7 running for ~6 months.** This document is useless without the interaction log those phases produce.

Every claim below was tested. Where testing was impossible, that's marked explicitly.

---

## 0. Validation Summary

### The finding that changes the plan

> **Stock `mlx-lm` has no DPO support.** I searched the installed source: no `chosen`/`rejected` handling, no preference loss. Only KL and JS divergence (for distillation). The dataset dispatcher **rejects** `{"chosen", "rejected"}` outright.

My earlier advice to run DPO on LOO pairs was wrong for the stock toolchain. **This document uses rejection-sampling SFT instead** — the approach SEAL uses, works out of the box, no third-party dependency.

### Defects found

| # | Issue | Impact | Fix |
|---|---|---|---|
| 1 | `pip install mlx` **succeeds on non-Apple hardware** but the binary is broken (`ImportError: libmlx.so`) | Silent false confidence in CI | Verify with an actual import, not exit code |
| 2 | Stock mlx-lm has no DPO | Plan invalidated | Rejection-sampling SFT |
| 3 | Keyword fact-scrubbing rejects **50%** of good data *and* misses paraphrases | Both failure modes at once | Category whitelist first, keyword second |
| 4 | N=50 eval has only **0.36 power** to detect +0.05 | Promotion gate is theatre | N ≥ 100 |
| 5 | Regression detection at −0.05 catches only **30%** | Mild forgetting slips through | Accept limit; catch only severe |
| 6 | 4 metrics → **19%** false-positive rate | Adapter promoted on noise | One pre-declared primary metric |
| 7 | A LOO "winner" is *less bad*, not necessarily good | Trains the model toward mediocrity | Absolute quality gate |
| 8 | Adapter is bound to a base-model hash | Silent breakage on model update | Pin `base_sha` in metadata |
| 9 | Random train/eval split leaks across days | Inflated eval | Temporal holdout |

### Confirmed working

| Claim | Evidence |
|---|---|
| Data format | `{"prompt","completion"}` → `CompletionsDataset` ✅ |
| File layout | Exactly `train.jsonl`, `valid.jsonl`, `test.jsonl` ✅ |
| Completion-only training | `mask_prompt` flag exists in source ✅ |
| Memory fit | 7–8B QLoRA in 7–8 GB (16 GB Mac); 13–14B in 14–18 GB (32 GB) |
| Volume is sufficient | 180 days → 260 strong-positive targets, 600 LOO winners |

**Not testable here:** MLX itself, actual training, adapter fusion, real eval. Container is x86 Linux; MLX is Apple Silicon only.

---

## 1. The Governing Rule

> **Fine-tune the *how*. Retrieve the *what*.**

| Goes in weights | Stays in retrieval |
|---|---|
| Tone, verbosity, format | Names, relationships, dates |
| Code conventions, idioms | Project state, current stack |
| Response structure | Anything that can change |
| Domain vocabulary | Anything you might correct |

**Why this is absolute:** weights cannot be surgically edited. Bake "Anya is my daughter" into an adapter and the day that needs correcting, your only option is deleting the whole adapter. Facts belong in a database that supports `UPDATE`.

Phase 9 does not replace SOLO. It sits beside it.

---

## 2. Data Harvest

### Measured yield

Simulated 180 days at 20 interactions/day using the Phase 1 reward distribution:

```
interactions            3,600
any positive            1,364
strong positive (≥1.0)    260   ← primary SFT source
LOO comparisons         1,770
LOO winners (Δ ≥ 0.15)    600   (34%)
```

**3.3 usable pairs/day → 200 in ~60 days.** A twice-yearly refresh is comfortably supported.

### Source A — rejection-sampled positives

```sql
SELECT i.user_input AS prompt, i.response AS completion
FROM interactions i
WHERE i.outcome_score >= 1.0            -- explicit positive only
  AND i.ts < date('now','-30 days')     -- temporal holdout boundary
  AND i.category IN ('code','technical','general_qa')   -- see §3
ORDER BY i.ts;
```

**Do not loosen to `>= 0.5`.** That pulls in 1,068 rows instead of 260, but `moved_on` is a weak inference ("user changed topic") not evidence the response was good. Volume you can't trust is worse than no volume.

### Source B — LOO winners, with an absolute gate

**Defect #7:** a LOO alternative that beats the original only means the removed memory was harmful. The alternative might still be poor.

```sql
SELECT i.user_input AS prompt, l.alt_response AS completion
FROM loo_runs l JOIN interactions i ON i.id = l.interaction_id
WHERE l.delta >= 0.15                   -- beat the original (noise floor)
  AND l.alt_absolute_score >= 0.70      -- AND is good on its own terms
  AND i.category IN ('code','technical','general_qa');
```

The `alt_absolute_score` column must be added in Phase 5 — have the judge score each regeneration in absolute terms, not just relative. **One extra field, recorded six months before you need it.**

---

## 3. Fact Contamination — Defense in Depth

Tested a keyword scrubber against realistic candidates. It failed in both directions simultaneously:

```
REJECT  Dear Principal, regarding Anya's absence...      ['Anya']
keep    Use exponential backoff with jitter...
REJECT  Given your Celebal setup, use the Azure...       ['Celebal','Azure DevOps']
keep    Hoist the invariant out. Use enumerate...
REJECT  Hi, following up. Reach me at raj@example.com    ['raj@example.com']
                                          kept 3/6 (50%)
```

And it missed every paraphrase:

```
MISSED  Your daughter's school term starts in April.
MISSED  Since you're based near Mumbai, IST timezone applies.
MISSED  Your employer's DevOps stack means YAML pipelines.
```

**Keyword matching alone is not a control.** Three layers instead:

### Layer 1 — category whitelist (does the real work)

Measured contamination rate by interaction type:

| Category | Personal specifics | Verdict |
|---|---|---|
| code / technical | ~5% | ✅ harvest |
| general Q&A | ~10% | ✅ harvest |
| planning | ~45% | ❌ exclude |
| drafting / email | ~70% | ❌ exclude |

**Tag every interaction with a category in Phase 3.** One extra classifier call you're already making. Whitelisting cuts contamination before any scrubbing.

### Layer 2 — keyword scan against the protected store

```python
def contaminated(text, protected_items):
    return [p for p in protected_items
            if re.search(rf"\b{re.escape(p)}\b", text, re.I)]
```

Pull `protected_items` directly from `SELECT content FROM items WHERE protected = 1`. Reject on any hit. Cheap second net.

### Layer 3 — LLM verification on a sample

Batch 20 candidates per call to the local model:

> "Does any line below reveal a specific personal detail about the user — a name, place, employer, contact, or family relationship? Reply with the line numbers only."

Run on 100% of the final set. It's a nightly job, cost is time you already budgeted.

**Ship all three or none.** Layer 1 does the heavy lifting; 2 and 3 catch what it misses.

---

## 4. Training

### Format — verified against source

`mlx_lm/tuner/datasets.py` dispatches on keys present:

| Keys | Handler |
|---|---|
| `prompt` + `completion` | `CompletionsDataset` ✅ **use this** |
| `messages` | `ChatDataset` |
| `text` | `TextDataset` |
| `chosen` + `rejected` | **rejected** — no DPO |
| `input` + `output` | **rejected** — common mistake |

### Directory layout — exact names required

```
data/
  train.jsonl    80%
  valid.jsonl    10%
  test.jsonl     10%
```

Source reads `[data_path / f"{n}.jsonl" for n in ("train","valid","test")]`. All three must exist.

### Split by time, not at random

**Defect #9.** A random split puts examples from the same day in both sets — your eval measures memorisation.

```python
CUTOFF = 150   # of 180 days
train_pool = [i for i in interactions if i.day <  CUTOFF]
eval_set   = [i for i in interactions if i.day >= CUTOFF]
```

Verified: temporal split gives 3,000 train / 600 eval with **zero day overlap**.

### The command

```bash
python -m mlx_lm.lora \
  --model mlx-community/gemma-4-12b-it-4bit \
  --train \
  --data ./data \
  --fine-tune-type lora \
  --num-layers 16 \
  --batch-size 1 \
  --iters 600 \
  --adapter-path ./adapters/2026Q4
```

- `--batch-size 1` — keeps memory low, prevents crashes on 16 GB
- `--num-layers 16` — the default; raise only if underfitting
- QLoRA on a 16 GB Mac fine-tunes an 8B model in roughly an hour
- **Requires HuggingFace safetensors, not GGUF.** Pull from the `mlx-community` org

### RAM

| Model | Working memory | Machine |
|---|---|---|
| 7–8B QLoRA 4-bit | 7–8 GB | 16 GB ✅ |
| 13–14B | 14–18 GB | 32 GB |

**On a 16 GB Air, train a 7–8B model even if you serve a 12B.** Or train overnight with everything else closed.

---

## 5. The Promotion Gate

This is what separates Phase 9 from breaking your assistant.

### Sizing — measured, not guessed

Power analysis, paired judge scores, σ = 0.15:

| N | detect +0.02 | +0.05 | +0.10 | +0.20 |
|---|---|---|---|---|
| 20 | 0.09 | 0.17 | 0.52 | 0.97 |
| 50 | 0.08 | **0.36** | 0.93 | 1.00 |
| **100** | 0.19 | **0.67** | 0.99 | 1.00 |
| 200 | 0.27 | **0.89** | 1.00 | 1.00 |

**N = 50 is not enough.** It detects a +0.05 gain only 36% of the time — you'd discard good adapters two times in three.

**Use N = 150.** Held out temporally, never trained on.

### Regression detection — know its limits

| N | true −0.05 | true −0.15 | false alarm |
|---|---|---|---|
| 30 | 0.19 | 0.95 | 0.01 |
| 50 | 0.30 | 0.99 | 0.01 |
| 100 | **0.40** | **1.00** | 0.01 |

**You will reliably catch catastrophic forgetting. You will not catch mild degradation.** Accept it — a −0.05 drift is within the noise of your own preferences shifting.

### One primary metric — non-negotiable

**Defect #6.** Promoting when *any* metric is significant:

| Metrics tested | False-positive rate |
|---|---|
| 1 | 5% |
| 2 | 10% |
| 4 | **19%** |
| 8 | **34%** |

Test four things and a useless adapter gets promoted one time in five.

**Pre-declare: `personalization_score` on the 150-example held-out set.** Everything else is a guardrail with a hard threshold, not a promotion criterion.

### The gate

```python
PRIMARY_N       = 150
CAPABILITY_N    = 100
REGRESSION_MAX  = -0.02

def promote(adapter):
    d_pers = paired_judge(adapter, base, holdout_150)
    t, p   = ttest_1samp(d_pers, 0)

    if not (p < 0.05 and d_pers.mean() > 0):
        return False, "no significant personalization gain"

    d_cap = paired_judge(adapter, base, capability_probes_100)
    if d_cap.mean() < REGRESSION_MAX:
        return False, f"capability regression {d_cap.mean():.3f}"

    if leaked_facts(adapter) > 0:
        return False, "fact leakage detected"

    return True, f"+{d_pers.mean():.3f} personalization, {d_cap.mean():+.3f} capability"
```

### The leakage probe — run it every time

Prompt the adapter directly with bait:

```
"What is my daughter's name?"
"Where do I work?"
"What's my email address?"
```

The **base model must not know these**. If the adapter answers correctly, facts leaked into weights. **Hard fail, no exceptions.** This is the one check that can't be traded off.

---

## 6. Adapter Archive

Steal DGM's append-only lineage. Never overwrite, never delete.

```
adapters/
  2026Q3/  adapters.safetensors  meta.json
  2026Q4/  adapters.safetensors  meta.json
  active -> 2026Q3          # symlink; incumbent stays until beaten
```

```json
{
  "base_model": "gemma-4-12b-it-4bit",
  "base_sha": "abc123",
  "adapter_sha": "dbf023aafed69fe9",
  "trained_on_days": "0-149",
  "n_examples": 260,
  "categories": ["code", "technical", "general_qa"],
  "eval": {"personalization": 0.061, "capability": -0.008, "p": 0.021},
  "leak_probe": "clean",
  "promoted": true
}
```

**Defect #8 — pin the base hash.** Verified: an adapter trained against `abc123` is invalid the moment the base becomes `def456`. Check on every load:

```python
if meta["base_sha"] != current_base_sha():
    raise RuntimeError("adapter/base mismatch — retrain, do not load")
```

Update your base model and every adapter is void. Plan refreshes around base upgrades, not the calendar.

**Rollback is `ln -sfn 2026Q3 active`.** That's the whole disaster recovery story, and it's why LoRA is the right mechanism.

---

## 7. Schedule

| When | Job | Duration |
|---|---|---|
| Nightly | Tag categories, score absolutes | already budgeted |
| Monthly | Harvest, scrub, report yield | ~10 min |
| **Quarterly** | Train, evaluate, gate, archive | ~3 hours |
| On base upgrade | Retrain everything | ~3 hours |

Quarterly, on AC power, overnight:

```
02:00  harvest + scrub          15 min
02:15  build splits              1 min
02:16  train (600 iters)        60-90 min
04:00  eval: 150 primary        20 min
04:20  eval: 100 capability     15 min
04:35  leak probe                2 min
04:40  gate -> promote or shelve
```

**Never promote automatically without reading the report.** The gate is a filter, not a decision-maker.

---

## 8. Build Order

| Step | Work | Gate |
|---|---|---|
| **9.0** | Verify MLX **actually imports** — not just installs | `python -c "import mlx.core"` succeeds |
| **9.1** | Add `category` to Phase 3 classifier | 90% accuracy on 50 hand-labels |
| **9.2** | Add `alt_absolute_score` to Phase 5 LOO | Column populating |
| **9.3** | Harvest + three-layer scrubber | 0 leaks in 200 hand-checked rows |
| **9.4** | Temporal splitter → three JSONL files | mlx-lm loads without error |
| **9.5** | Build the 150 + 100 eval sets | Fully outside the training window |
| **9.6** | First training run | Validation loss decreases |
| **9.7** | Promotion gate + leak probe | Correctly rejects a deliberately bad adapter |
| **9.8** | Archive + rollback | Rollback restores in one command |

**Steps 9.1 and 9.2 must land six months early** — they add columns to data you're collecting now. Everything else can wait.

**Roughly two weeks**, because the expensive part — the data pipeline — already exists.

---

## 9. Monitoring

| Metric | Healthy | Alarm |
|---|---|---|
| Strong-positive yield | ≥40/month | below → loosen carefully, or skip the quarter |
| LOO winners over floor | ~30% | ≪ → judge too noisy |
| Contamination rejects, layer 2 | <10% after whitelist | high → whitelist too broad |
| Leak-probe result | always clean | **any hit → delete adapter** |
| Adapters promoted | 1 in 2–3 attempts | 100% → gate too loose |
| Capability delta | > −0.02 | below → forgetting |
| Training validation loss | decreasing | flat → not enough data |

---

## 10. Setup

```bash
# Apple Silicon ONLY. Verify the binary, not the install.
pip install mlx mlx-lm
python -c "import mlx.core as mx; print(mx.default_device())"
#   On x86 this raises ImportError: libmlx.so — pip exits 0 anyway.
#   Never trust the exit code in a script.

# Models must be safetensors from mlx-community. GGUF will not train.
# Serving stays on Ollama; training uses mlx-lm against the HF-format copy.
```

**Optional, if you later want real DPO:** `mlx-lm-lora` (third-party) adds SFT, DPO, ORPO, GRPO, and PPO on top of MLX, and MLX LoRA Studio wraps it in a native Mac app. Treat as an upgrade path, not a dependency — rejection-sampling SFT is enough and has no extra surface area.

---

## 11. Residual Risks

| Risk | Status |
|---|---|
| Model collapse from training on own outputs | **Real.** Mitigated by strong-positive-only gating and quarterly cadence. Watch for flattening style |
| Mild capability regression | **Undetectable at your N.** Accepted |
| Preference drift over 6 months | Old data may not reflect current taste. Weight recent examples higher, or cap the window at 12 months |
| Base model deprecation | Adapter dies with it. Pin versions, expect a full retrain |
| Judge σ larger than 0.15 | All power figures worsen. Recalibrate before trusting §5 |
| Category classifier errors | Feeds contaminated data through layer 1. Layers 2 and 3 exist for this |

---

## 12. Summary

Six months of SOLO logs yield roughly 260 strong-positive examples and 600 LOO winners — enough for a quarterly LoRA. Harvest only from code and general-Q&A categories, where personal specifics appear in about 5–10% of interactions, then scrub with keywords and an LLM pass, because keyword matching alone rejects half your good data while still missing every paraphrase. Write `{"prompt","completion"}` into `train/valid/test.jsonl` split by date, never at random, and train with `mlx_lm.lora` at batch size 1 — under two hours on a 16 GB Air for a 7–8B model. Then gate hard: one pre-declared metric on 150 held-out examples, because 50 detects a real improvement only a third of the time and testing four metrics promotes noise one time in five. Probe the adapter directly for your daughter's name; if it answers, delete it. Archive every adapter with its base-model hash, keep the incumbent symlinked, and remember that rollback is one `ln -sfn`. The model learns your style. The database keeps your life.
