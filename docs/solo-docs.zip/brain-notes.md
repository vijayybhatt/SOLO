# How the Brain Works — Simple Notes

Plain-language notes. No jargon. Everything tagged by layer.

---

## The 3 Major Layers

| Layer | Nickname | Job |
|---|---|---|
| **Cortex** | The thinker | Thinking, understanding, planning, deciding — **and long-term storage** |
| **Inner brain** | The feeler | Emotion, memory **filtering**, body control |
| **Brainstem** | The survivor | Breathing, heartbeat, sleep, reflexes |

**One line:** stem keeps you alive, inner brain keeps you feeling, cortex keeps you thinking.

---

## 1. Brainstem — the background service

- Runs automatically from birth to death — you never switch it on
- **Breathing** — keeps lungs going even in sleep
- **Heartbeat** — keeps the pace right
- **Blood pressure** — keeps it steady
- **Sleep–wake switch** — flips you between awake and asleep
- **Reflexes** — coughing, swallowing, blinking

Key points:
- **Nothing is stored here.** No learning, no memory, no choice
- It's hardwired, not shaped by experience
- If this crashes, nothing else in the brain matters

**Analogy:** it's the operating system running underneath. Cortex and inner brain are the apps.

---

## 2. Inner brain — the feeling and memory layer

Four main parts:

| Part | Nickname | Job |
|---|---|---|
| **Thalamus** | Post office | Sorts and forwards incoming signals |
| **Amygdala** | Alarm | Flags danger and emotion, instantly |
| **Hippocampus** | Bouncer | Decides what's worth remembering |
| **Hypothalamus** | Thermostat | Hunger, thirst, temperature, hormones |

### The order it fires

```
Signal in → Thalamus → Amygdala → Hippocampus → Hypothalamus
```

### Where the thalamus sends things

- It's a post office, not a destination
- Sound → hearing area (**cortex**, temporal lobe)
- Sight → vision area (**cortex**, occipital lobe)
- Touch → touch area (**cortex**, parietal lobe)
- It sends **two copies**: one fast to the amygdala, one slower to the cortex
- Only smell skips the thalamus entirely

### What the hypothalamus does

- Controls hunger, thirst, body temperature, sleep timing
- Releases stress hormones when the amygdala shouts
- Basically: **turns emotions into physical body changes**

---

## Worked Example — a dog barks behind you

1. Sound waves hit your **ear** (input, not brain)
2. Ear converts it to an electrical signal → sent into the brain
3. Signal reaches the **thalamus** (inner brain)
4. Thalamus makes two copies:
   - **Copy A → amygdala** (inner brain, milliseconds) → "THREAT!" → you flinch
   - **Copy B → hearing area** (cortex, slower) → "that's a dog"
5. **Cortex** works it out → "just a dog, relax" → body calms down

**Why you jump first and feel silly after:** Copy A wins the race.

**Roles:** ear = microphone · thalamus = post office · temporal lobe = the one who reads the message.

---

## 3. Memory — how the hippocampus decides

### The big correction

The hippocampus is **not a save button — it's a filter.**

### Where memories actually live

- The hippocampus (inner brain) **does not store long-term memories**
- It **filters, indexes, and hands off** — holding things temporarily, then passing them to the cortex during sleep
- **Permanent storage is in the cortex**, spread across the same areas that did the original perceiving
- So the cortex does **both** thinking *and* storing. It isn't either/or

**Analogy:** the bouncer isn't the club. The hippocampus checks who gets in; the cortex is the building where they stay.

- Your brain takes in ~11 million bits per second; only ~40 bits reach awareness
- Most experiences **never get recorded at all**
- Forgetting is an **active process**, not a bug
- Almost nobody remembers everything — the rare condition (HSAM) has fewer than 100 identified cases worldwide, and even then only for personal life events, not general facts

### The scoring system

Four things raise a memory's score:

1. **Attention** (cortex) — did you actually focus? *This is the gate. No attention = never reaches memory.*
2. **Emotion** (amygdala, inner brain) — did it matter to you?
3. **Novelty** (inner brain) — was it new or surprising? New things trigger a chemical boost
4. **Repetition** — did it happen again and again?

High score → replayed during sleep → moved to cortex → permanent.
Low score → never replayed → quietly fades.

### Kept vs discarded — first day at a new job

| Kept | Discarded |
|---|---|
| Your manager's face and name | The receptionist you passed once |
| The awkward intro you fumbled | What you had for lunch |
| Where the bathroom is (used daily) | The exact desk layout |
| The joke that landed | Most of the onboarding slides |

### Who decides?

Nobody consciously. It's automatic scoring — mostly **emotional tag + attention paid**.

### Why day 1 is vivid and day 300 is a blur

- Day 1 is 100% novel → everything gets a boost
- Day 300 is routine → nothing scores
- Not a malfunction. Day 300 contained no new information

### Sleep is where it actually commits

- During deep sleep the hippocampus replays the day and transfers keepers to the **cortex**
- Replay time is limited, so only top-scoring events get replayed
- Missing one night of good sleep cuts new memory formation by roughly 40%

---

## The Robot Analogy

A robot switched on for the first time in a new house.

**Second 1 — the flood.** A million readings per second. Storage is finite. It can't keep this.

**Its rule:** *"Will this change what I do next time?"*

Four things raise the score:

1. **Did it change something?** Tripped on a step → high. Cloud passed the window → zero
2. **Was it unexpected?** Predicted door closed, found it open → save. Predicted flat floor, floor was flat → discard
3. **Did it happen again?** One squeak → noise. Squeak every single time → pattern, save
4. **Will it need this later?** Charging port location → save forever. Rug pattern → drop

**End of day one:**

| Saved | Erased |
|---|---|
| The step it tripped on | Wall colors |
| Where the charging port is | The fridge hum |
| The human's face and voice | A bird flying past |
| The door that sticks | Exact chair positions |

**Nightly cleanup:** replays the day at high speed. Replayed items become permanent rules ("this house has a step at the kitchen entrance"). Unreplayed items expire.

**Core idea:** the robot isn't recording its life. It's building a **shorter and shorter set of rules for how the world behaves** — and throws away every observation that doesn't improve those rules.

**Yours works the same way.**

---

## How to Deliberately Store Something

- **Focus fully** — no phone, no multitasking. This is the gate; nothing gets past it
- **Make it novel or weird** — bizarre sticks, plain doesn't
- **Attach emotion or stakes** — "why does this matter to me?"
- **Self-test, don't re-read** — pulling it out beats putting it in again
- **Space it out** — day 1, day 3, day 7, day 21
- **Sleep after learning** — this is when the transfer actually happens

**The formula:** attention + connection + testing + sleep.

### Bonus trick from the research

Weak memories that would normally be forgotten can be **rescued by novelty happening nearby in time**.

- Study boring material → then immediately do something novel (walk a new route, watch something surprising)
- The boring material piggybacks on the novelty boost

---

## The Cortex — four lobes (not yet covered in detail)

Remember: this layer does the thinking **and** holds the long-term memories.

| Lobe | Location | Job |
|---|---|---|
| **Frontal** | Front | Thinking, planning, decisions, personality, movement |
| **Parietal** | Top | Touch, temperature, spatial awareness |
| **Temporal** | Sides | Hearing, language, memory access |
| **Occipital** | Back | Vision |

---

## Quick Recap

- **Brainstem** → background service. Keeps you alive. Learns nothing
- **Inner brain** → routes signals, reacts emotionally, filters memory
- **Cortex** → understands, plans, and stores long-term
- **Inner brain is fast and automatic; cortex is slow but smart** — that's why you react first and think after
- **Memory isn't a recording** — it's a rule-builder that keeps only what changes your future behaviour
