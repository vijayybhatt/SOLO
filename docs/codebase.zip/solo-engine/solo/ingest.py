"""The write path: extraction, routing, grouping, protection."""
import re
import numpy as np
from . import prompts
from .llm import parse_choice

# Match the PATTERN, not just the word. "reach me at raj@x.com" contains no
# literal "email" and was landing in `episodic` instead of `personal`.
GROUP_RULES = [
    ("personal",   re.compile(
        r"\b(name|daughter|son|wife|husband|family|birthday|phone|email|address)\b"
        r"|[\w.+-]+@[\w-]+\.[\w.]+"
        r"|\+?\d[\d\s-]{8,}\d", re.I)),
    ("preference", re.compile(
        r"\b(prefer|like|dislike|hate|always|never|style|tone|format|short|detailed|concise)\b", re.I)),
    ("technical",  re.compile(
        r"\b(python|sql|azure|aws|api|version|library|framework|stack|deploy|docker|git)\b", re.I)),
    ("project",    re.compile(
        r"\b(project|deadline|client|sprint|milestone|goal|roadmap)\b", re.I)),
]
GROUPS = [g for g, _ in GROUP_RULES] + ["episodic"]

PROTECT_RE = re.compile(
    r"\b(daughter|son|wife|husband|mother|father|birthday|diagnos|medication|allerg)\b"
    r"|\+?\d[\d\s-]{8,}\d|[\w.+-]+@[\w-]+\.[\w.]+", re.I)

EXPLICIT_RE = re.compile(
    r"\b(remember|note that|don'?t forget|keep in mind|from now on|always|never)\b", re.I)


def assign_group(text):
    for gid, pat in GROUP_RULES:
        if pat.search(text):
            return gid
    return "episodic"


def is_protected(text, model_said=False):
    """Fail toward protection: a wrongly-protected item costs storage,
    a wrongly-unprotected one gets evicted and ends trust."""
    return bool(PROTECT_RE.search(text)) or bool(model_said)


def is_explicit(text):
    return bool(EXPLICIT_RE.search(text))


def route(sim, contradicts, cfg):
    """Contradiction is checked BEFORE duplication. In the other order a
    near-identical correction ("Ananya, not Anya") is dropped as a duplicate."""
    if sim >= cfg.sim_related and contradicts:
        return "SUPERSEDE"
    if sim >= cfg.sim_dup:
        return "DROP_DUPLICATE"
    if sim >= cfg.sim_related:
        return "MERGE_OR_SKIP"
    return "INSERT_NEW"


def parse_facts(raw, cap):
    if not raw or str(raw).strip().upper().startswith("NONE"):
        return []
    out = []
    for line in str(raw).strip().splitlines():
        parts = line.split("|", 2)
        if len(parts) == 3 and parts[0].strip().upper() == "FACT":
            text = parts[2].strip()
            if text:
                out.append({"content": text, "kind": "fact",
                            "protected": parts[1].strip().lower() == "protected"})
    return out[:cap]                       # hard cap in code, not just the prompt


def parse_rules(raw, cap):
    if not raw or str(raw).strip().upper().startswith("NONE"):
        return []
    out = []
    for line in str(raw).strip().splitlines():
        parts = line.split("|", 1)
        if len(parts) == 2 and parts[0].strip().upper() == "RULE":
            t = parts[1].strip()
            if t:
                out.append({"content": t, "kind": "rule", "protected": False})
    return out[:cap]


def ingest(db, emb_store, candidates, cfg, llm=None):
    """Insert / supersede / drop. Returns counts."""
    stats = dict(inserted=0, dropped=0, superseded=0, skipped=0)
    cap = cfg.extract_cap
    for cand in list(candidates)[:cap]:
        text = (cand.get("content") or "").strip()
        if not text:
            continue
        v = emb_store.encode(text)

        rows = db.execute(
            "SELECT id, vec_row, content FROM items "
            "WHERE deleted_at IS NULL AND superseded_by IS NULL").fetchall()
        best_sim, best = 0.0, None
        if rows and len(emb_store.mat):
            vrows = [r["vec_row"] for r in rows]
            sims = emb_store.rows(vrows) @ v
            i = int(np.argmax(sims))
            best_sim, best = float(sims[i]), rows[i]

        contradicts = False
        if best is not None and best_sim >= cfg.sim_related and llm is not None:
            raw = llm.complete(
                prompts.CONTRADICTS.format(existing=best["content"], new=text),
                model=cfg.model_small, max_tokens=4, fallback="NO")
            contradicts = parse_choice(raw, ["YES", "NO"], "NO") == "YES"

        action = route(best_sim, contradicts, cfg)
        if action == "DROP_DUPLICATE":
            stats["dropped"] += 1
            continue
        if action == "MERGE_OR_SKIP":
            stats["skipped"] += 1
            continue

        gid = assign_group(text)
        vr = emb_store.add(v)
        cur = db.execute(
            "INSERT INTO items (vec_row,kind,content,group_id,protected,valid_from) "
            "VALUES (?,?,?,?,?,datetime('now'))",
            (vr, cand.get("kind", "fact"), text, gid,
             int(is_protected(text, cand.get("protected", False)))))
        new_id = cur.lastrowid
        db.execute("INSERT OR IGNORE INTO groups (group_id) VALUES (?)", (gid,))

        if action == "SUPERSEDE":
            db.execute("UPDATE items SET superseded_by=?, valid_until=datetime('now') "
                       "WHERE id=?", (new_id, best["id"]))
            stats["superseded"] += 1
        else:
            stats["inserted"] += 1

    db.commit()
    emb_store.save()
    return stats
