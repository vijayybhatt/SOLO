"""Embedding store: BGE-small via Ollama + one memory-mapped .npy matrix.

numpy brute force beats sqlite-vec 6-9x at this scale and avoids the
enable_load_extension problem that breaks sqlite-vec on macOS system Python.
"""
import os, hashlib
import numpy as np
from pathlib import Path


class EmbedStore:
    def __init__(self, path, dim=384, llm=None):
        self.path, self.dim, self.llm = path, dim, llm
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        if os.path.exists(path):
            self.mat = np.load(path).astype(np.float32)
            if self.mat.ndim != 2 or self.mat.shape[1] != dim:
                raise ValueError(f"{path} has shape {self.mat.shape}, expected (*,{dim}). "
                                 "Embedding model changed? Rebuild the matrix.")
        else:
            self.mat = np.zeros((0, dim), dtype=np.float32)

    def _fallback(self, text):
        """Deterministic hash embedding. Used only when the model is unreachable,
        so the pipeline degrades instead of crashing."""
        v = np.zeros(self.dim, dtype=np.float32)
        for tok in set(str(text).lower().split()) or {""}:
            h = int(hashlib.sha256(tok.encode()).hexdigest()[:16], 16)
            v += np.random.default_rng(h).standard_normal(self.dim).astype(np.float32)
        n = np.linalg.norm(v)
        return v / n if n > 0 else v

    def encode(self, text):
        vec = None
        if self.llm is not None:
            raw = self.llm.embed(text)
            if raw is not None:
                vec = np.asarray(raw, dtype=np.float32)
                if vec.shape != (self.dim,):
                    vec = None
        if vec is None:
            vec = self._fallback(text)
        n = float(np.linalg.norm(vec))
        return vec / n if n > 0 else vec     # L2 normalise -> dot == cosine

    def add(self, vec):
        vec = np.asarray(vec, dtype=np.float32).reshape(1, self.dim)
        self.mat = vec.copy() if len(self.mat) == 0 else np.vstack([self.mat, vec])
        return len(self.mat) - 1

    def rows(self, idx):
        idx = np.asarray(idx, dtype=np.int64)
        if len(idx) == 0:
            return np.zeros((0, self.dim), dtype=np.float32)
        return self.mat[idx]

    def save(self):
        """Atomic: the hot path may be reading this file."""
        tmp = self.path + ".tmp.npy"
        np.save(tmp, self.mat)
        os.replace(tmp, self.path)
