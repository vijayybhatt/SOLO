"""
The single gateway for every model call.

Two hard-won facts, both verified against a live Ollama 0.5.7 server:

1. openai exceptions do NOT inherit from Python builtins. `openai.OpenAIError`
   subclasses `Exception` directly. A handler catching
   `(ConnectionError, TimeoutError, RuntimeError)` catches NONE of them, so
   every Ollama failure propagates and crashes the caller.

2. `/v1/models` returns `{"object":"list","data":null}` when no models are
   installed. `for m in resp.data` raises TypeError; `for m in resp` is safe.
"""
import json, re, logging

log = logging.getLogger("solo.llm")

try:
    import openai
    _OPENAI_ERRORS = (
        openai.APIConnectionError,   # server down / refused
        openai.APITimeoutError,      # hung or unroutable
        openai.APIStatusError,       # 4xx/5xx incl. NotFoundError (model not pulled)
        openai.APIError,
        openai.OpenAIError,
    )
except Exception:                     # pragma: no cover
    openai = None
    _OPENAI_ERRORS = ()

LLM_ERRORS = _OPENAI_ERRORS + (ConnectionError, TimeoutError, OSError, RuntimeError)


def guarded(fn, fallback, label="llm"):
    """Never let a model failure crash the caller. Never swallow a real bug."""
    try:
        return fn()
    except LLM_ERRORS as e:
        log.warning("%s degraded: %s", label, type(e).__name__)
        return fallback
    except Exception as e:
        log.error("%s UNEXPECTED: %s", label, type(e).__name__)
        raise


def parse_score(text, lo=0.0, hi=1.0):
    """
    Survives real small-model output. Plain json.loads handles 3/12 of the
    formats these models actually emit, and turns {"score": 8} into 8.0 on a
    0-1 scale -- silent corruption rather than a crash.
    """
    if not text or not str(text).strip():
        return None
    text = str(text)
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.S)   # reasoning leak
    text = re.sub(r"```(?:json)?|```", "", text)                 # code fences

    m = re.search(r"\{.*?\}", text, re.S)
    if m:
        s = re.sub(r",\s*([}\]])", r"\1", m.group(0))            # trailing comma
        obj = None
        for cand in (s, s.replace("'", '"')):                    # single quotes
            try:
                obj = json.loads(cand)
                break
            except Exception:
                continue
        if isinstance(obj, dict) and "score" in obj:
            try:
                v = float(obj["score"])
            except (TypeError, ValueError):
                return None
            if v > hi:
                v /= 10.0                                        # model used 0-10
            return max(lo, min(hi, v))

    m = re.search(r"(\d*\.?\d+)", text)                          # last resort
    if m:
        v = float(m.group(1))
        if v > hi:
            v /= 10.0
        return max(lo, min(hi, v))
    return None


def parse_choice(text, allowed, default):
    if not text:
        return default
    t = str(text).strip().strip('".\'').lower()
    for a in allowed:
        if t.startswith(a.lower()):
            return a
    return default


class LLMClient:
    """Thin wrapper over the OpenAI-compatible endpoint Ollama exposes."""

    def __init__(self, cfg):
        self.cfg = cfg
        self._c = None
        self.calls = 0
        self.failures = 0

    @property
    def client(self):
        if self._c is None:
            if openai is None:
                raise RuntimeError("openai package not installed")
            self._c = openai.OpenAI(base_url=self.cfg.base_url,
                                    api_key=self.cfg.api_key)
        return self._c

    def available_models(self):
        """Iterate the response, never resp.data -- Ollama returns null there.
        Returns None if the server is unreachable, [] if reachable but empty."""
        def _go():
            return [m.id for m in self.client.models.list()]
        return guarded(_go, None, "models.list")

    def ping(self):
        return self.available_models() is not None

    def complete(self, prompt, model=None, max_tokens=256, temperature=0.0,
                 system=None, fallback=None):
        msgs = ([{"role": "system", "content": system}] if system else []) + \
               [{"role": "user", "content": prompt}]

        def _go():
            self.calls += 1
            r = self.client.chat.completions.create(
                model=model or self.cfg.model_main, messages=msgs,
                max_tokens=max_tokens, temperature=temperature,
                timeout=self.cfg.llm_timeout_s)
            return r.choices[0].message.content

        out = guarded(_go, None, "complete")
        if out is None:
            self.failures += 1
            return fallback
        return out

    def embed(self, text):
        def _go():
            self.calls += 1
            r = self.client.embeddings.create(
                model=self.cfg.model_embed, input=text,
                timeout=self.cfg.llm_timeout_s)
            return r.data[0].embedding
        out = guarded(_go, None, "embed")
        if out is None:
            self.failures += 1
        return out
