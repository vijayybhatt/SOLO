"""SOLO Engine — a self-learning memory layer for local LLMs."""
__version__ = "1.0.0"
from .config import Config, validate_config
from .engine import Engine
__all__ = ["Config", "validate_config", "Engine", "__version__"]
