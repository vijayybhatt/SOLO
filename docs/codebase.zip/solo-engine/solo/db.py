"""SQLite schema and connections. WAL mode, adaptive eviction, no FK traps."""
import sqlite3, os
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS items (
    id              INTEGER PRIMARY KEY,
    vec_row         INTEGER NOT NULL UNIQUE,
    kind            TEXT    NOT NULL CHECK (kind IN ('fact','rule')),
    content         TEXT    NOT NULL,
    group_id        TEXT    NOT NULL,
    alpha           REAL    NOT NULL DEFAULT 0,
    beta            REAL    NOT NULL DEFAULT 0,
    protected       INTEGER NOT NULL DEFAULT 0,
    valid_from      TEXT,
    valid_until     TEXT,
    recorded_at     TEXT    NOT NULL DEFAULT (datetime('now')),
    superseded_by   INTEGER REFERENCES items(id),
    deleted_at      TEXT,
    conditions      TEXT,
    evidence_count  INTEGER NOT NULL DEFAULT 2,
    context_cluster INTEGER,
    last_retrieved  TEXT,
    retrieval_count INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS groups (
    group_id   TEXT PRIMARY KEY,
    alpha_sum  REAL NOT NULL DEFAULT 1,
    beta_sum   REAL NOT NULL DEFAULT 9,
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS interactions (
    id              INTEGER PRIMARY KEY,
    session_id      TEXT NOT NULL,
    ts              TEXT NOT NULL DEFAULT (datetime('now')),
    day             INTEGER NOT NULL DEFAULT 0,
    user_input      TEXT NOT NULL,
    input_vec       BLOB,
    response        TEXT,
    category        TEXT,
    context_cluster INTEGER,
    outcome_event   TEXT,
    outcome_score   REAL,
    judge_reasoning TEXT,
    scored_at       TEXT
);

CREATE TABLE IF NOT EXISTS retrievals (
    interaction_id     INTEGER NOT NULL REFERENCES interactions(id),
    item_id            INTEGER NOT NULL REFERENCES items(id),
    rank               INTEGER NOT NULL,
    similarity         REAL NOT NULL,
    sampled_theta      REAL NOT NULL,
    propensity         REAL NOT NULL,
    loo_delta          REAL,
    alt_absolute_score REAL,
    was_culprit        INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (interaction_id, item_id)
);

CREATE TABLE IF NOT EXISTS shadow (
    interaction_id INTEGER NOT NULL REFERENCES interactions(id),
    item_id        INTEGER NOT NULL,
    rank           INTEGER NOT NULL,
    PRIMARY KEY (interaction_id, item_id)
);

CREATE TABLE IF NOT EXISTS loo_queue (
    interaction_id INTEGER PRIMARY KEY REFERENCES interactions(id),
    queued_at      TEXT NOT NULL DEFAULT (datetime('now')),
    attempts       INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT);

CREATE INDEX IF NOT EXISTS items_live  ON items (kind, group_id) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS inter_day   ON interactions (day);
CREATE INDEX IF NOT EXISTS inter_sess  ON interactions (session_id, id);
CREATE INDEX IF NOT EXISTS retr_item   ON retrievals (item_id);
"""


def connect(path: str) -> sqlite3.Connection:
    """One connection per thread. SQLite connections are not thread-safe."""
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(path, timeout=5.0)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA foreign_keys=ON")
    db.execute("PRAGMA synchronous=NORMAL")
    db.executescript(SCHEMA)
    db.commit()
    return db


def get_meta(db, k, default=None):
    r = db.execute("SELECT v FROM meta WHERE k=?", (k,)).fetchone()
    return r["v"] if r else default


def set_meta(db, k, v):
    db.execute("INSERT INTO meta(k,v) VALUES(?,?) "
               "ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, str(v)))
    db.commit()


def evict(db, cfg, day: int) -> int:
    """
    Both thresholds are adaptive.

    A fixed observation threshold is unreachable when decay is on:
    equilibrium_obs = daily_gain / (1 - decay). At decay=0.990 that ceiling is
    ~15, so a hard-coded 20 can never be met and eviction silently never fires.
    """
    if day < cfg.evict_enabled_after_day:
        return 0
    row = db.execute("""
        SELECT AVG(alpha / NULLIF(alpha + beta, 0)) AS mean_score,
               AVG(alpha + beta)                    AS mean_obs
        FROM items WHERE deleted_at IS NULL AND superseded_by IS NULL
    """).fetchone()
    if not row or row["mean_score"] is None or row["mean_obs"] is None:
        return 0
    obs_cut = cfg.evict_obs_ratio * row["mean_obs"]
    score_cut = cfg.evict_score_ratio * row["mean_score"]
    cur = db.execute("""
        UPDATE items SET deleted_at = datetime('now')
        WHERE deleted_at IS NULL
          AND superseded_by IS NULL
          AND protected = 0
          AND alpha + beta >= ?
          AND alpha / NULLIF(alpha + beta, 0) < ?
          AND (last_retrieved IS NULL
               OR last_retrieved < datetime('now', ?))
    """, (obs_cut, score_cut, f"-{cfg.evict_unused_days} days"))
    db.commit()
    return cur.rowcount
