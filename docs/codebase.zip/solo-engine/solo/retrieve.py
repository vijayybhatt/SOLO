"""Thompson Sampling over hierarchically pooled Beta posteriors."""
import numpy as np


def pooled_params(alpha, beta, g_alpha, g_beta, cfg):
    """
    Leave-one-out pooling: an item must not inform its own prior.
    phi is clamped because Beta(0, x) raises ValueError.
    """
    ga = np.maximum(np.asarray(g_alpha, float) - alpha, 1e-6)
    gb = np.maximum(np.asarray(g_beta, float) - beta, 1e-6)
    phi = np.clip(ga / (ga + gb), cfg.phi_min, cfg.phi_max)
    return cfg.kappa * phi + alpha, cfg.kappa * (1.0 - phi) + beta


def retrieve(q_vec, emb, alpha, beta, g_alpha, g_beta, cfg, rng,
             thompson=True):
    """
    Returns local indices into the arrays passed in.

    Note on propensity: it sums to n_retrieve over ALL candidates, not over
    the chosen subset (that sums to 2-6). Monitor the former.
    """
    n = len(alpha)
    empty = dict(chosen=np.array([], int), sim=np.array([]), theta=np.array([]),
                 prop=np.array([]), shadow=np.array([], int))
    if n == 0 or len(emb) == 0:
        return empty

    sim = emb @ q_vec
    k = min(cfg.n_retrieve, n)
    nc = min(cfg.n_candidate, n)
    cand = np.argpartition(-sim, nc - 1)[:nc] if n > nc else np.arange(n)
    s = sim[cand]
    shadow = np.argsort(-sim)[:k]                      # plain similarity RAG

    if not thompson:                                   # bootstrap phase
        chosen = shadow
        return dict(chosen=chosen, sim=sim[chosen],
                    theta=np.ones(len(chosen)), prop=np.ones(len(chosen)),
                    shadow=shadow)

    a_eff, b_eff = pooled_params(alpha[cand], beta[cand],
                                 g_alpha[cand], g_beta[cand], cfg)
    theta = rng.beta(a_eff, b_eff)
    order = np.argsort(-(s * theta))[:k]

    draws = rng.beta(a_eff, b_eff, size=(cfg.n_mc, len(cand)))
    ranks = np.argsort(-(s * draws), axis=1)[:, :k]
    prop = np.bincount(ranks.ravel(), minlength=len(cand)) / cfg.n_mc
    prop = np.clip(prop, cfg.prop_floor, 1.0)

    return dict(chosen=cand[order], sim=s[order], theta=theta[order],
                prop=prop[order], shadow=shadow)
