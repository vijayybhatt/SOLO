"""All tunables. Values marked CALIBRATE must be measured on your data."""
from dataclasses import dataclass, asdict, fields
import json, math


@dataclass
class Config:
    # ── storage ──────────────────────────────────────────────
    db_path: str = "data/solo.db"
    npy_path: str = "data/embeddings.npy"

    # ── models ───────────────────────────────────────────────
    base_url: str = "http://localhost:11434/v1"
    api_key: str = "ollama"
    model_main: str = "gemma4:12b"
    model_small: str = "gemma4:e2b"      # set == model_main on a 16 GB machine
    model_embed: str = "bge-small-en-v1.5"
    embed_dim: int = 384
    llm_timeout_s: float = 30.0

    # ── scoring ──────────────────────────────────────────────
    kappa: float = 10.0                  # pooling strength, in equivalent observations
    prior_a: float = 1.0                 # global prior Beta(1,9) -> 0.10
    prior_b: float = 9.0
    phi_min: float = 0.02                # clamp; outside this numpy raises ValueError
    phi_max: float = 0.98
    decay: float = 0.990                 # nightly discount, ~70-day half-life

    # ── retrieval ────────────────────────────────────────────
    n_candidate: int = 50
    n_retrieve: int = 8
    n_mc: int = 500                      # Monte Carlo draws for propensity
    prop_floor: float = 1e-2             # 1e-3 produces 1000x IPS weights

    # ── rewards ──────────────────────────────────────────────
    r_positive: float = 1.0
    r_moved_on: float = 0.5
    r_thanks: float = 0.3
    r_failure: float = -1.0
    split_positive: bool = True          # MANDATORY: replicating causes 10:1 drift
    moved_on_alarm: float = 0.40         # above this share, detector is trigger-happy

    # ── attribution ──────────────────────────────────────────
    loo_enabled: bool = False            # CALIBRATE: enable only if acc >= loo_min_acc
    loo_k: int = 3
    loo_queue_max: int = 20
    noise_floor: float = 0.15            # CALIBRATE: 1.5 x measured judge sigma
    loo_min_acc: float = 0.35
    blame_all: float = -0.3

    # ── ingest ───────────────────────────────────────────────
    sim_dup: float = 0.95                # CALIBRATE on 100 real embedding pairs
    sim_related: float = 0.82            # CALIBRATE; must be < sim_dup
    extract_cap: int = 5
    rule_cap: int = 3
    explicit_sla_s: int = 60

    # ── eviction (both thresholds adaptive) ──────────────────
    evict_obs_ratio: float = 0.8         # x mean observations
    evict_score_ratio: float = 0.5       # x mean score
    evict_unused_days: int = 90
    evict_enabled_after_day: int = 30

    # ── OPE ──────────────────────────────────────────────────
    ope_min_prop: float = 0.05           # exclude below this; do NOT floor
    ope_min_rows: int = 30

    # ── topic detection ──────────────────────────────────────
    topic_low: float = 0.35              # CALIBRATE on 50 labelled pairs
    topic_high: float = 0.60

    # ── cold start ───────────────────────────────────────────
    bootstrap_days: int = 7              # similarity-only before this
    warming_days: int = 30               # no eviction before this

    def equilibrium_obs(self, daily_gain: float) -> float:
        """Decay imposes a hard ceiling on accumulated evidence."""
        if self.decay >= 1.0:
            return math.inf
        return daily_gain / (1.0 - self.decay)

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2)

    @classmethod
    def from_json(cls, s: str) -> "Config":
        d = json.loads(s)
        known = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in d.items() if k in known})


class ConfigError(ValueError):
    pass


def validate_config(c: Config) -> bool:
    """Cross-checks that catch silently incoherent configs. Run on boot."""
    e = []
    if c.n_retrieve > c.n_candidate:
        e.append("n_retrieve > n_candidate")
    if c.prop_floor >= c.ope_min_prop:
        e.append("prop_floor must be < ope_min_prop")
    if c.sim_related >= c.sim_dup:
        e.append("sim_related must be < sim_dup")
    if c.kappa > 25:
        e.append("kappa > 25: the group drowns the individual")
    if c.kappa <= 0:
        e.append("kappa must be > 0")
    if 1.0 / c.prop_floor > 200:
        e.append(f"max IPS weight {1/c.prop_floor:.0f}x is too high")
    if c.loo_k > c.n_retrieve:
        e.append("loo_k > n_retrieve")
    if c.prior_a / (c.prior_a + c.prior_b) > 0.25:
        e.append("prior is not pessimistic")
    if not (0.95 <= c.decay <= 1.0):
        e.append("decay outside [0.95, 1.0]")
    if c.decay < 0.97:
        e.append("decay too aggressive: discards real signal")
    if not (0.0 < c.phi_min < c.phi_max < 1.0):
        e.append("require 0 < phi_min < phi_max < 1")
    if not c.split_positive:
        e.append("split_positive=False causes 10:1 upward drift")
    if c.topic_low >= c.topic_high:
        e.append("topic_low must be < topic_high")
    if c.embed_dim <= 0:
        e.append("embed_dim must be > 0")
    if e:
        raise ConfigError("incoherent config: " + "; ".join(e))
    return True
