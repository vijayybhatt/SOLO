"""Outcome scoring. Positives are SPLIT across contributors, never replicated."""
import numpy as np

EVENTS = ("explicit_positive", "moved_on", "thanks", "neutral", "no_return", "failure")


def reward_for(event, cfg):
    return {"explicit_positive": cfg.r_positive,
            "moved_on": cfg.r_moved_on,
            "thanks": cfg.r_thanks,
            "neutral": 0.0,
            "no_return": 0.0,
            "failure": cfg.r_failure}.get(event, 0.0)


def apply_reward(r, item_rows, alpha, beta, g_alpha_by, g_beta_by, groups, cfg,
                 culprit=None):
    """
    Replicating the full reward to each of k retrieved items while penalising
    one culprit yields a 10:1 positive/negative mass ratio: the mean posterior
    drifts to 0.729 and climbs, and eviction never fires. Splitting gives 1.3:1.
    One good answer is worth one unit of credit.
    """
    rows = np.asarray(item_rows, dtype=np.int64)
    if r == 0 or len(rows) == 0:
        return
    if r > 0:
        share = (r / len(rows)) if cfg.split_positive else r
        alpha[rows] += share
        np.add.at(g_alpha_by, groups[rows], share)
    else:
        mag = abs(r)
        if culprit is not None:
            beta[culprit] += mag
            g_beta_by[groups[culprit]] += mag
        else:
            share = abs(cfg.blame_all)
            beta[rows] += share
            np.add.at(g_beta_by, groups[rows], share)


def decay_evidence(alpha, beta, g_alpha_by, g_beta_by, cfg):
    """
    Scales alpha and beta equally: preserves the mean, shrinks confidence.
    Decay does not correct a stale score -- it makes the score correctable.

    Caps total evidence at daily_gain / (1 - decay). Any absolute observation
    threshold must be checked against that ceiling.
    """
    alpha *= cfg.decay
    beta *= cfg.decay
    g_alpha_by[:] = cfg.prior_a + (g_alpha_by - cfg.prior_a) * cfg.decay
    g_beta_by[:] = cfg.prior_b + (g_beta_by - cfg.prior_b) * cfg.decay
