"""The orchestrator. chat() is the only entry point the host app needs."""
import time, json, logging
import numpy as np

from . import prompts
from .db import connect, evict, get_meta, set_meta
from .embed import EmbedStore
from .llm import LLMClient, guarded, parse_score, parse_choice
from .retrieve import retrieve
from .reward import apply_reward, decay_evidence, reward_for
from .ingest import ingest, parse_facts, parse_rules, is_explicit, GROUPS
from .ope import snips, rule_support

log = logging.getLogger("solo.engine")


class Engine:
    def __init__(self, cfg, db=None, emb=None, llm=None, rng=None):
        self.cfg = cfg
        self.db = db or connect(cfg.db_path)
        self.llm = llm if llm is not None else LLMClient(cfg)
        self.emb = emb or EmbedStore(cfg.npy_path, cfg.embed_dim, self.llm)
        self.rng = rng or np.random.default_rng()
        self.day = int(get_meta(self.db, "day", 0))
        self._prev = {}                       # session -> dict
        self.timings = []
        self.reload()

    # ── state ────────────────────────────────────────────────
    def reload(self):
        rows = self.db.execute(
            "SELECT id, vec_row, group_id, alpha, beta FROM items "
            "WHERE deleted_at IS NULL AND superseded_by IS NULL ORDER BY id").fetchall()
        self.ids = np.array([r["id"] for r in rows], dtype=np.int64)
        self.vrows = np.array([r["vec_row"] for r in rows], dtype=np.int64)
        self.alpha = np.array([r["alpha"] for r in rows], dtype=np.float64)
        self.beta = np.array([r["beta"] for r in rows], dtype=np.float64)
        self.gnames = GROUPS
        gi = {g: i for i, g in enumerate(self.gnames)}
        self.groups = np.array([gi.get(r["group_id"], len(self.gnames) - 1)
                                for r in rows], dtype=np.int64)
        stored = {r["group_id"]: r for r in self.db.execute("SELECT * FROM groups")}
        self.g_alpha_by = np.array(
            [stored[g]["alpha_sum"] if g in stored else self.cfg.prior_a
             for g in self.gnames], dtype=np.float64)
        self.g_beta_by = np.array(
            [stored[g]["beta_sum"] if g in stored else self.cfg.prior_b
             for g in self.gnames], dtype=np.float64)

    def persist(self):
        for i, iid in enumerate(self.ids):
            self.db.execute("UPDATE items SET alpha=?, beta=? WHERE id=?",
                            (float(self.alpha[i]), float(self.beta[i]), int(iid)))
        for g, i in ((g, i) for i, g in enumerate(self.gnames)):
            self.db.execute(
                "INSERT INTO groups (group_id,alpha_sum,beta_sum) VALUES (?,?,?) "
                "ON CONFLICT(group_id) DO UPDATE SET alpha_sum=excluded.alpha_sum, "
                "beta_sum=excluded.beta_sum, updated_at=datetime('now')",
                (g, float(self.g_alpha_by[i]), float(self.g_beta_by[i])))
        set_meta(self.db, "day", self.day)
        self.db.commit()

    # ── hot path ─────────────────────────────────────────────
    def chat(self, user_input, session="default", generate=True):
        t0 = time.perf_counter()
        q = self.emb.encode(user_input)

        if session in self._prev:
            self._score_previous(session, q, user_input)

        use_thompson = self.day >= self.cfg.bootstrap_days
        r = retrieve(q, self.emb.rows(self.vrows), self.alpha, self.beta,
                     self.g_alpha_by[self.groups] if len(self.ids) else np.array([]),
                     self.g_beta_by[self.groups] if len(self.ids) else np.array([]),
                     self.cfg, self.rng, thompson=use_thompson)

        cur = self.db.execute(
            "INSERT INTO interactions (session_id, day, user_input, input_vec) "
            "VALUES (?,?,?,?)", (session, self.day, user_input, q.tobytes()))
        iid = cur.lastrowid
        for rank, loc in enumerate(r["chosen"]):
            self.db.execute(
                "INSERT OR IGNORE INTO retrievals "
                "(interaction_id,item_id,rank,similarity,sampled_theta,propensity) "
                "VALUES (?,?,?,?,?,?)",
                (iid, int(self.ids[loc]), rank, float(r["sim"][rank]),
                 float(r["theta"][rank]), float(r["prop"][rank])))
            self.db.execute("UPDATE items SET last_retrieved=datetime('now'), "
                            "retrieval_count=retrieval_count+1 WHERE id=?",
                            (int(self.ids[loc]),))
        for rank, loc in enumerate(r["shadow"]):
            self.db.execute("INSERT OR IGNORE INTO shadow VALUES (?,?,?)",
                            (iid, int(self.ids[loc]), rank))
        self.db.commit()
        self.timings.append((time.perf_counter() - t0) * 1000)

        memories = [self.db.execute("SELECT content FROM items WHERE id=?",
                                    (int(self.ids[l]),)).fetchone()["content"]
                    for l in r["chosen"]]
        response = None
        if generate:
            ctx = "\n".join(f"- {m}" for m in memories)
            response = self.llm.complete(
                user_input, system=f"What you know about the user:\n{ctx}" if ctx else None,
                fallback=None)
            self.db.execute("UPDATE interactions SET response=? WHERE id=?",
                            (response, iid))
            self.db.commit()

        if is_explicit(user_input):
            self.ingest_now([{"content": user_input}])

        self._prev[session] = dict(iid=iid, vec=q, text=user_input,
                                   chosen=r["chosen"], response=response)
        return dict(interaction_id=iid, memories=memories, response=response,
                    retrieved=len(r["chosen"]), used_thompson=use_thompson)

    # ── outcome scoring ──────────────────────────────────────
    def _score_previous(self, session, q_vec, curr_text):
        p = self._prev.pop(session)
        already = self.db.execute("SELECT scored_at FROM interactions WHERE id=?",
                                  (p["iid"],)).fetchone()
        if already and already["scored_at"] is not None:
            return                        # host app already scored it explicitly
        sim = float(p["vec"] @ q_vec)
        if sim < self.cfg.topic_low:
            new_topic = True
        elif sim > self.cfg.topic_high:
            new_topic = False
        else:
            raw = self.llm.complete(
                prompts.TOPIC.format(prev=p["text"], curr=curr_text),
                model=self.cfg.model_small, max_tokens=4, fallback=None)
            new_topic = parse_choice(raw, ["NEW", "CONTINUE"], "CONTINUE") == "NEW"

        event = "moved_on" if new_topic else "neutral"
        if p["response"]:
            raw = self.llm.complete(
                prompts.JUDGE.format(user_input=p["text"], response=p["response"]),
                model=self.cfg.model_small, max_tokens=8, fallback=None)
            score = parse_score(raw)
            if score is not None:
                event = "failure" if score < 0.4 else ("explicit_positive"
                                                       if score > 0.8 else event)
        self.record_outcome(p["iid"], event, p["chosen"])

    def record_outcome(self, iid, event, chosen=None, force=False):
        """
        Idempotent. Without the guard, a retry or a manual score followed by
        automatic scoring applies the reward twice and corrupts the posteriors.
        """
        row = self.db.execute(
            "SELECT scored_at FROM interactions WHERE id=?", (iid,)).fetchone()
        if row is None:
            log.warning("record_outcome: unknown interaction %s", iid)
            return False
        if row["scored_at"] is not None and not force:
            log.debug("interaction %s already scored; ignoring", iid)
            return False

        r = reward_for(event, self.cfg)
        if chosen is None:
            chosen = np.array([self._row_of(x["item_id"]) for x in self.db.execute(
                "SELECT item_id FROM retrievals WHERE interaction_id=?", (iid,))
                if self._row_of(x["item_id"]) is not None], dtype=np.int64)
        culprit = None
        if r < 0 and self.cfg.loo_enabled and len(chosen):
            self._queue_loo(iid)
        apply_reward(r, chosen, self.alpha, self.beta,
                     self.g_alpha_by, self.g_beta_by, self.groups, self.cfg, culprit)
        self.db.execute("UPDATE interactions SET outcome_event=?, outcome_score=?, "
                        "scored_at=datetime('now') WHERE id=?", (event, r, iid))
        self.db.commit()
        return True

    def _row_of(self, item_id):
        w = np.where(self.ids == item_id)[0]
        return int(w[0]) if len(w) else None

    def _queue_loo(self, iid):
        n = self.db.execute("SELECT count(*) c FROM loo_queue").fetchone()["c"]
        if n < self.cfg.loo_queue_max:
            self.db.execute("INSERT OR IGNORE INTO loo_queue(interaction_id) VALUES (?)",
                            (iid,))
            self.db.commit()

    # ── ingest ───────────────────────────────────────────────
    def ingest_now(self, candidates):
        st = ingest(self.db, self.emb, candidates, self.cfg, self.llm)
        if st["inserted"] or st["superseded"]:
            self.persist(); self.reload()
        return st

    # ── batch ────────────────────────────────────────────────
    def nightly(self):
        """Consolidate, decay, evict. Run on AC power, off the hot path."""
        out = {}
        convo = self.db.execute(
            "SELECT user_input, response FROM interactions WHERE day=? LIMIT 40",
            (self.day,)).fetchall()
        if convo:
            text = "\n".join(f"U: {r['user_input']}\nA: {r['response'] or ''}"
                             for r in convo)[:6000]
            raw = self.llm.complete(
                prompts.EXTRACT_FACTS.format(cap=self.cfg.extract_cap, conversation=text),
                max_tokens=400, fallback=None)
            out["ingest"] = self.ingest_now(parse_facts(raw, self.cfg.extract_cap))

        decay_evidence(self.alpha, self.beta, self.g_alpha_by, self.g_beta_by, self.cfg)
        self.persist()
        out["evicted"] = evict(self.db, self.cfg, self.day)
        if out["evicted"]:
            self.reload()
        self.day += 1
        set_meta(self.db, "day", self.day)
        return out

    def weekly_ope(self):
        results = {}
        for row in self.db.execute(
                "SELECT id FROM items WHERE kind='rule' AND deleted_at IS NULL"):
            rows, var = rule_support(self.db, row["id"], self.cfg)
            if var <= 0:
                results[row["id"]] = (None, "no propensity variance")
                continue
            est, status = snips([(r["p"], 1.0, r["y"]) for r in rows], self.cfg)
            results[row["id"]] = (est, status)
        return results

    # ── monitoring ───────────────────────────────────────────
    def health(self):
        q = lambda s, *a: self.db.execute(s, a).fetchone()
        n = q("SELECT count(*) c FROM items WHERE deleted_at IS NULL")["c"]
        scored = q("SELECT count(*) c FROM interactions WHERE outcome_score IS NOT NULL")["c"]
        moved = q("SELECT count(*) c FROM interactions WHERE outcome_event='moved_on'")["c"]
        pos = q("SELECT COALESCE(SUM(outcome_score),0) s FROM interactions "
                "WHERE outcome_score>0")["s"]
        neg = q("SELECT COALESCE(-SUM(outcome_score),0) s FROM interactions "
                "WHERE outcome_score<0")["s"]
        obs = (self.alpha + self.beta) if len(self.ids) else np.array([0.0])
        ov = self.db.execute("""
            SELECT AVG(o) FROM (
              SELECT (SELECT count(*) FROM retrievals r JOIN shadow s
                        ON s.interaction_id=r.interaction_id AND s.item_id=r.item_id
                       WHERE r.interaction_id=i.id) AS o
              FROM interactions i WHERE i.day >= ?)""",
            (max(0, self.day - 7),)).fetchone()[0]
        return dict(
            day=self.day, items=n, scored=scored,
            median_obs=float(np.median(obs)),
            moved_on_share=(moved / scored) if scored else 0.0,
            moved_on_alarm=(scored > 20 and moved / scored > self.cfg.moved_on_alarm),
            pos_neg_ratio=(pos / neg) if neg else float("inf"),
            shadow_divergence=(1 - ov / self.cfg.n_retrieve) if ov else None,
            hot_path_p50_ms=float(np.percentile(self.timings, 50)) if self.timings else None,
            hot_path_p99_ms=float(np.percentile(self.timings, 99)) if self.timings else None,
            llm_calls=self.llm.calls, llm_failures=self.llm.failures)
