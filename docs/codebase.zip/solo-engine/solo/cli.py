"""solo — command line entry points."""
import argparse, json, sys
import numpy as np

from .config import Config, validate_config
from .engine import Engine
from .llm import LLMClient


def cmd_doctor(args):
    cfg = Config()
    print("config validation:", end=" ")
    try:
        validate_config(cfg); print("PASS")
    except Exception as e:
        print("FAIL —", e); return 1

    llm = LLMClient(cfg)
    models = llm.available_models()          # None = unreachable, [] = no models
    if models is None:
        print(f"ollama at {cfg.base_url}: UNREACHABLE — is `ollama serve` running?")
    else:
        print(f"ollama at {cfg.base_url}: reachable")
        print(f"models installed: {models or '(none)'}")
        for want in (cfg.model_main, cfg.model_small, cfg.model_embed):
            ok = want in models
            print(f"  {want:<22} {'OK' if ok else 'MISSING — ollama pull ' + want}")

    gain = 0.15
    print(f"\ndecay ceiling: equilibrium_obs = {cfg.equilibrium_obs(gain):.1f} "
          f"at decay={cfg.decay}, daily_gain={gain}")
    print("eviction thresholds are adaptive, so no fixed value can exceed it")

    print("\nCALIBRATE before trusting the loop:")
    for k in ("sim_dup", "sim_related", "topic_low", "topic_high",
              "noise_floor", "loo_enabled"):
        print(f"  {k:<14} = {getattr(cfg, k)}")
    return 0


def cmd_health(args):
    cfg = Config()
    eng = Engine(cfg)
    print(json.dumps(eng.health(), indent=2, default=str))
    h = eng.health()
    if h["moved_on_alarm"]:
        print("\nALARM: moved_on share above threshold — the topic detector is "
              "trigger-happy and +0.5 has become a participation trophy. "
              "Raise topic_low and recalibrate.", file=sys.stderr)
    return 0


def cmd_nightly(args):
    cfg = Config()
    eng = Engine(cfg)
    print(json.dumps(eng.nightly(), indent=2, default=str))
    return 0


def cmd_chat(args):
    cfg = Config()
    eng = Engine(cfg)
    out = eng.chat(args.text, session=args.session)
    print(f"[{out['retrieved']} memories, thompson={out['used_thompson']}]")
    for m in out["memories"]:
        print("  -", m)
    print("\n" + (out["response"] or "(no model reachable)"))
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(prog="solo")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("doctor", help="check config and models").set_defaults(fn=cmd_doctor)
    sub.add_parser("health", help="print monitoring snapshot").set_defaults(fn=cmd_health)
    sub.add_parser("nightly", help="run consolidation").set_defaults(fn=cmd_nightly)
    c = sub.add_parser("chat", help="one turn")
    c.add_argument("text"); c.add_argument("--session", default="cli")
    c.set_defaults(fn=cmd_chat)
    a = p.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
