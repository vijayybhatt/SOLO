# Install

## 1. Models (one time, needs network)

```bash
brew install ollama
ollama serve &
ollama pull gemma4:12b            # reasoning + LOO
ollama pull gemma4:e2b            # classification (set = gemma4:12b on 16 GB)
ollama pull bge-small-en-v1.5     # embeddings
```

**16 GB Macs:** set `model_small = model_main`. Both resident plus macOS and a
browser exceeds the budget; swapping costs more than the slower classifier calls.

**Never pull a cloud-tagged model.** Ollama can serve cloud models and those
queries leave the machine.

## 2. Package

```bash
pip install -r requirements.txt
python -m solo.cli doctor
```

`doctor` reports UNREACHABLE if `ollama serve` isn't running, and lists any
missing models.

## 3. Verify

```bash
pip install -r requirements-dev.txt
pytest                  # 96 tests
python demo.py          # 30 simulated days, no model needed
```

## 4. Confirm it is offline

```bash
sudo pfctl -ef - <<< "block drop out proto tcp from any to any user ollama"
python demo.py          # must still pass
```

## Schedule

```python
from apscheduler.schedulers.background import BackgroundScheduler
s = BackgroundScheduler()
s.add_job(eng.nightly,    'cron', hour=2)                       # AC power only
s.add_job(eng.weekly_ope, 'cron', day_of_week='sun', hour=3)
s.start()
```

Gate the nightly job on AC power — sustained inference on a fanless Air drains
the battery and throttles.
