# SOLO Engine

A self-learning memory layer for local LLMs. Fully offline, no weight updates.

Memories carry a Beta posterior that rises and falls based on whether **using
them actually worked**. Retrieval ranks by `similarity × proven-usefulness`
rather than similarity alone.

```
pip install -r requirements.txt
python demo.py                     # 30 simulated days, no model needed
python -m solo.cli doctor          # check config + models
```

---

## Status

```
95 tests passing
```

Built and validated against the design docs. Every defect listed in
`DEFECTS.md` has a regression test.

---

## Quick start

```python
from solo import Config, validate_config, Engine

cfg = Config(model_main="gemma4:12b", model_embed="bge-small-en-v1.5")
validate_config(cfg)               # raises on incoherent settings
eng = Engine(cfg)

out = eng.chat("How should I structure a retry?", session="user1")
print(out["response"])

# score it when you learn the outcome (idempotent)
eng.record_outcome(out["interaction_id"], "explicit_positive")

# nightly, on AC power
eng.nightly()
```

## Layout

```
solo/
  config.py      all tunables + validate_config()
  db.py          SQLite schema (WAL), adaptive eviction
  embed.py       BGE-small via Ollama + one .npy matrix
  llm.py         the ONLY gateway for model calls; guarded(), parse_score()
  retrieve.py    Thompson Sampling over pooled Beta posteriors
  reward.py      split positives, targeted negatives, evidence decay
  ingest.py      extraction, routing, grouping, protection
  ope.py         SNIPS off-policy evaluation
  prompts.py     five versioned prompts
  engine.py      orchestrator — chat(), record_outcome(), nightly()
  cli.py         solo doctor / health / nightly / chat
tests/           95 tests
demo.py          30-day run, no model dependency
```

## The design in one paragraph

Everything lives in one SQLite file and one `.npy` matrix. Retrieval is numpy
brute force — similarity times a Thompson draw from each item's Beta posterior,
pooled leave-one-out against its group, with Monte Carlo propensities logged so
rules can later be validated off-policy. Positive outcomes **split** one unit of
credit across contributors; negatives target a single culprit. Evidence decays
nightly so stale confidence becomes correctable. Nothing writes to weights and
nothing leaves the machine.

## Non-obvious things that matter

| | Why |
|---|---|
| Positives are **split**, not replicated | Replicating gives a 10:1 mass ratio; the mean drifts to 0.729 and eviction never fires |
| Eviction thresholds are **adaptive** | Decay caps evidence at `daily_gain/(1−decay)` ≈ 15. A fixed `>= 20` is unreachable |
| `parse_score` is not `json.loads` | Plain parsing handles 3/12 real outputs, and turns `{"score": 8}` into 8.0 on a 0–1 scale |
| `guarded()` catches `openai.APIError` | Those exceptions are **not** builtin `ConnectionError`. Catching builtins catches nothing |
| Contradiction is checked **before** dedup | Reversed, "Ananya not Anya" is dropped as a duplicate |
| `record_outcome` is **idempotent** | Double-scoring applied the reward twice |
| `for m in resp` never `resp.data` | Ollama returns `data: null` with no models installed |
| Shadow A/B runs from day one | No internal metric can detect that SOLO is worse than plain RAG |

## Calibrate before trusting the loop

| Setting | How |
|---|---|
| `sim_dup`, `sim_related` | 100 real embedding pairs |
| `topic_low`, `topic_high` | 50 hand-labelled message pairs |
| `noise_floor` | 20 judge repeats on 30 samples → 1.5 × σ |
| `loo_enabled` | 40 hand-labelled failures. **Below 0.35 accuracy, leave it off** — blame-all scores 0.51 against LOO's 0.43 |

`python -m solo.cli doctor` prints the current values.

## Expectations

- Thompson Sampling is inert until roughly day 7–14
- Eviction is disabled until day 30
- Precision lands near **0.39–0.55**, about double baseline — not the 0.93 an
  idealised simulation suggests
- The shadow A/B divergence trend is the only honest signal. **Flat after 60
  days means stop building**

## Tests

```
pytest                     # all 95
pytest -m "not slow"       # skip the multi-day behavioural runs
```
