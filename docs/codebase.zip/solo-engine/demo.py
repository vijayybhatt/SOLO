#!/usr/bin/env python3
"""Runs SOLO for 30 simulated days with no model dependency.

Shows the loop working end to end: ingest -> retrieve -> score -> decay ->
evict, with the shadow A/B harness recording what plain similarity RAG
would have picked.
"""
import sys, os, tempfile, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "tests"))

from solo.config import Config, validate_config
from solo.db import connect
from solo.embed import EmbedStore
from solo.engine import Engine
from conftest import FakeLLM

TOPICS = ["python deploy pipeline", "family school daughter", "azure sql database",
          "short concise answers", "project deadline client", "weather travel plans"]
HELPFUL = {0, 1, 2, 3}

def main():
    d = tempfile.mkdtemp(prefix="solo-demo-")
    cfg = Config(db_path=f"{d}/solo.db", npy_path=f"{d}/emb.npy")
    validate_config(cfg)
    llm = FakeLLM(seed=11)
    eng = Engine(cfg, db=connect(cfg.db_path),
                 emb=EmbedStore(cfg.npy_path, cfg.embed_dim, llm),
                 llm=llm, rng=np.random.default_rng(11))

    for t in TOPICS:
        for i in range(6):
            eng.ingest_now([{"content": f"{t} detail {i}"}])
    print(f"seeded {len(eng.ids)} memories\n")
    print(f"{'day':>4} {'items':>6} {'med.obs':>8} {'mean':>6} {'diverge':>8} {'evict':>6}")
    print("-" * 46)

    rng = np.random.default_rng(11)
    for day in range(30):
        for _ in range(20):
            t = int(rng.integers(0, len(TOPICS)))
            out = eng.chat(f"{TOPICS[t]} query {rng.integers(0,99999)}", generate=False)
            if rng.random() < 0.40:
                ev = "neutral"
            else:
                ev = "explicit_positive" if rng.random() < (0.8 if t in HELPFUL else 0.4) \
                     else "failure"
            eng.record_outcome(out["interaction_id"], ev)
        res = eng.nightly()
        if day % 5 == 4 or day == 0:
            h = eng.health()
            print(f"{h['day']:>4} {h['items']:>6} {h['median_obs']:>8.2f} "
                  f"{np.mean(eng.alpha/(eng.alpha+eng.beta+1e-9)):>6.3f} "
                  f"{(h['shadow_divergence'] or 0):>8.2f} {res['evicted']:>6}")

    print("\nfinal health:")
    for k, v in eng.health().items():
        print(f"  {k:<22} {v}")
    print(f"\nartifacts in {d}")

if __name__ == "__main__":
    main()
