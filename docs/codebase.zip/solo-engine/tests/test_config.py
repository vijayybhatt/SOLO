import pytest, math
from solo.config import Config, validate_config, ConfigError


def test_default_is_coherent():
    assert validate_config(Config())


@pytest.mark.parametrize("field,value", [
    ("split_positive", False),      # 10:1 drift
    ("decay", 0.90),                # discards real signal
    ("kappa", 50.0),                # group drowns individual
    ("kappa", 0.0),
    ("prop_floor", 0.10),           # >= ope_min_prop
    ("sim_related", 0.99),          # >= sim_dup
    ("n_retrieve", 100),            # > n_candidate
    ("prior_a", 5.0),               # not pessimistic
    ("loo_k", 99),                  # > n_retrieve
])
def test_incoherent_configs_rejected(field, value):
    with pytest.raises(ConfigError):
        validate_config(Config(**{field: value}))


def test_equilibrium_ceiling():
    """Decay caps evidence. A fixed threshold above the ceiling never fires."""
    c = Config(decay=0.990)
    assert math.isclose(c.equilibrium_obs(0.15), 15.0, rel_tol=1e-6)
    assert Config(decay=1.0).equilibrium_obs(0.15) == math.inf
    assert c.equilibrium_obs(0.15) < 20      # why a hard-coded 20 was unreachable


def test_json_roundtrip():
    c = Config(kappa=7.5)
    assert Config.from_json(c.to_json()) == c
