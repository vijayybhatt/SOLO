import sys, os, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np, pytest
from solo.config import Config
from solo.db import connect
from solo.embed import EmbedStore


class FakeLLM:
    """Deterministic stand-in. fail_rate injects real openai-style failures."""
    def __init__(self, fail_rate=0.0, seed=0):
        import random
        self.rng = random.Random(seed)
        self.fail_rate = fail_rate
        self.calls = 0
        self.failures = 0
        self.scripted = {}

    def complete(self, prompt, model=None, max_tokens=256, temperature=0.0,
                 system=None, fallback=None):
        self.calls += 1
        if self.rng.random() < self.fail_rate:
            self.failures += 1
            return fallback
        for key, val in self.scripted.items():
            if key in prompt:
                return val
        if "Number only" in prompt:
            return f"{self.rng.uniform(0.3, 0.95):.2f}"
        if "NEW or CONTINUE" in prompt:
            return self.rng.choice(["NEW", "CONTINUE"])
        if "YES or NO" in prompt:
            return "NO"
        return "NONE"

    def embed(self, text):
        return None      # force the deterministic fallback encoder


@pytest.fixture
def cfg(tmp_path):
    return Config(db_path=str(tmp_path / "t.db"), npy_path=str(tmp_path / "t.npy"))


@pytest.fixture
def db(cfg):
    d = connect(cfg.db_path)
    yield d
    d.close()


@pytest.fixture
def emb(cfg):
    return EmbedStore(cfg.npy_path, cfg.embed_dim, FakeLLM())


@pytest.fixture
def llm():
    return FakeLLM()


@pytest.fixture
def rng():
    return np.random.default_rng(1234)
