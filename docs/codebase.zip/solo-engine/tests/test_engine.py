import numpy as np, pytest
from solo.engine import Engine
from solo.db import connect
from solo.embed import EmbedStore
from conftest import FakeLLM


def _engine(cfg, fail_rate=0.0, seed=1):
    llm = FakeLLM(fail_rate=fail_rate, seed=seed)
    db = connect(cfg.db_path)
    emb = EmbedStore(cfg.npy_path, cfg.embed_dim, llm)
    return Engine(cfg, db=db, emb=emb, llm=llm,
                  rng=np.random.default_rng(seed)), llm


def test_empty_store_does_not_crash(cfg):
    eng, _ = _engine(cfg)
    out = eng.chat("hello there", generate=False)
    assert out["retrieved"] == 0
    assert eng.db.execute("SELECT count(*) c FROM interactions").fetchone()["c"] == 1


def test_bootstrap_uses_similarity_only(cfg):
    eng, _ = _engine(cfg)
    eng.ingest_now([{"content": f"python deploy tip {i}"} for i in range(5)])
    assert eng.day < cfg.bootstrap_days
    out = eng.chat("python deploy question", generate=False)
    assert out["used_thompson"] is False


def test_thompson_activates_after_bootstrap(cfg):
    eng, _ = _engine(cfg)
    eng.ingest_now([{"content": f"python deploy tip {i}"} for i in range(5)])
    eng.day = cfg.bootstrap_days
    assert eng.chat("python deploy question", generate=False)["used_thompson"]


def test_propensity_is_always_logged(cfg):
    eng, _ = _engine(cfg)
    eng.ingest_now([{"content": f"item {i} about azure"} for i in range(5)])
    eng.day = 10
    eng.chat("azure question", generate=False)
    rows = eng.db.execute("SELECT propensity FROM retrievals").fetchall()
    assert rows and all(r["propensity"] > 0 for r in rows)


def test_shadow_is_logged_for_ab(cfg):
    eng, _ = _engine(cfg)
    eng.ingest_now([{"content": f"item {i} about azure"} for i in range(5)])
    eng.day = 10
    iid = eng.chat("azure question", generate=False)["interaction_id"]
    assert eng.db.execute("SELECT count(*) c FROM shadow WHERE interaction_id=?",
                          (iid,)).fetchone()["c"] > 0


def test_explicit_instruction_ingests_immediately(cfg):
    eng, _ = _engine(cfg)
    before = len(eng.ids)
    eng.chat("Remember my daughter's name is Anya", generate=False)
    assert len(eng.ids) > before
    row = eng.db.execute("SELECT protected, group_id FROM items "
                         "ORDER BY id DESC LIMIT 1").fetchone()
    assert row["protected"] == 1 and row["group_id"] == "personal"


def test_survives_total_llm_failure(cfg):
    """Every model call fails; SOLO must degrade, never crash."""
    eng, llm = _engine(cfg, fail_rate=1.0)
    eng.ingest_now([{"content": f"fact {i}"} for i in range(4)])
    eng.day = 10
    for i in range(6):
        eng.chat(f"question {i}", generate=True)
    assert eng.db.execute("SELECT count(*) c FROM interactions").fetchone()["c"] == 6
    eng.nightly()


def test_outcome_updates_posteriors(cfg):
    eng, _ = _engine(cfg)
    eng.ingest_now([{"content": f"item {i} deploy"} for i in range(5)])
    eng.day = 10
    out = eng.chat("deploy question", generate=False)
    before = eng.alpha.sum()
    eng.record_outcome(out["interaction_id"], "explicit_positive")
    assert eng.alpha.sum() == pytest.approx(before + 1.0)   # one unit, split


def test_nightly_advances_day_and_decays(cfg):
    eng, _ = _engine(cfg)
    eng.ingest_now([{"content": f"item {i}"} for i in range(3)])
    eng.alpha[:] = 10.0
    d0 = eng.day
    eng.nightly()
    assert eng.day == d0 + 1
    assert eng.alpha.max() < 10.0


def test_health_reports_and_flags(cfg):
    eng, _ = _engine(cfg)
    eng.ingest_now([{"content": f"user works with tool number {i}"} for i in range(6)])
    n_items = len(eng.ids)
    eng.day = 10
    for i in range(30):
        out = eng.chat(f"python q {i}", generate=False)
        eng.record_outcome(out["interaction_id"], "moved_on")
    h = eng.health()
    assert h["items"] == n_items >= 1
    assert h["moved_on_share"] > cfg.moved_on_alarm
    assert h["moved_on_alarm"] is True          # the participation-trophy guard
    assert h["hot_path_p50_ms"] < 50


def test_hot_path_latency_budget(cfg):
    eng, _ = _engine(cfg)
    eng.ingest_now([{"content": f"item {i} topic"} for i in range(5)])
    eng.day = 10
    for i in range(40):
        eng.chat(f"topic query {i}", generate=False)
    assert np.percentile(eng.timings, 99) < 50


def test_state_survives_restart(cfg):
    eng, llm = _engine(cfg)
    eng.ingest_now([{"content": "user prefers concise answers"}])
    eng.day = 12
    eng.alpha[:] = 3.0
    eng.persist()
    eng.db.close()
    eng2, _ = _engine(cfg)
    assert eng2.day == 12
    assert len(eng2.ids) == 1
    assert eng2.alpha[0] == pytest.approx(3.0)


def test_record_outcome_is_idempotent(cfg):
    """Double-scoring corrupted the posteriors: alpha rose 2.5x for one outcome."""
    eng, _ = _engine(cfg)
    eng.ingest_now([{"content": "user prefers concise output"}])
    eng.day = 10
    iid = eng.chat("a question", generate=False)["interaction_id"]
    before = eng.alpha.sum()
    assert eng.record_outcome(iid, "explicit_positive") is True
    assert eng.record_outcome(iid, "explicit_positive") is False
    assert eng.alpha.sum() == pytest.approx(before + 1.0)


def test_auto_scoring_does_not_overwrite_manual(cfg):
    """_score_previous silently replaced 9 of 10 manual scores with 'neutral'."""
    eng, _ = _engine(cfg)
    eng.ingest_now([{"content": "user prefers concise output"}])
    eng.day = 10
    for i in range(10):
        out = eng.chat(f"question about topic {i}", generate=False)
        eng.record_outcome(out["interaction_id"], "moved_on")
    counts = {r["outcome_event"]: r["c"] for r in eng.db.execute(
        "SELECT outcome_event, count(*) c FROM interactions GROUP BY 1")}
    assert counts.get("moved_on") == 10


def test_record_outcome_unknown_interaction(cfg):
    eng, _ = _engine(cfg)
    assert eng.record_outcome(99999, "explicit_positive") is False


def test_force_rescore(cfg):
    eng, _ = _engine(cfg)
    eng.ingest_now([{"content": "x y z"}])
    eng.day = 10
    iid = eng.chat("q", generate=False)["interaction_id"]
    eng.record_outcome(iid, "thanks")
    assert eng.record_outcome(iid, "explicit_positive", force=True) is True
