import pytest, sqlite3
from solo.db import connect, evict, get_meta, set_meta


def _add(db, content, alpha, beta, protected=0, vec_row=None, group="episodic"):
    vec_row = vec_row if vec_row is not None else abs(hash(content)) % 10**8
    return db.execute(
        "INSERT INTO items (vec_row,kind,content,group_id,alpha,beta,protected) "
        "VALUES (?,?,?,?,?,?,?)",
        (vec_row, "fact", content, group, alpha, beta, protected)).lastrowid


def test_wal_and_fk_enabled(db):
    assert db.execute("PRAGMA journal_mode").fetchone()[0] == "wal"
    assert db.execute("PRAGMA foreign_keys").fetchone()[0] == 1


def test_soft_delete_uses_deleted_at_not_fk_sentinel(db):
    """superseded_by = -1 raises FOREIGN KEY constraint failed."""
    i = _add(db, "junk", 1, 40)
    db.commit()                       # commit first; rollback below must not undo it
    with pytest.raises(sqlite3.IntegrityError):
        db.execute("UPDATE items SET superseded_by=-1 WHERE id=?", (i,))
        db.commit()
    db.rollback()
    db.execute("UPDATE items SET deleted_at=datetime('now') WHERE id=?", (i,))
    db.commit()
    assert db.execute("SELECT deleted_at FROM items WHERE id=?", (i,)).fetchone()[0]


def test_eviction_is_disabled_during_warming(db, cfg):
    _add(db, "junk", 1, 40); db.commit()
    assert evict(db, cfg, day=5) == 0


def test_eviction_thresholds_are_adaptive(db, cfg):
    """A fixed obs threshold above the decay equilibrium never fires."""
    for i in range(10):
        _add(db, f"good {i}", 8, 2, vec_row=100 + i)
    _add(db, "junk", 0.2, 9, vec_row=200)
    db.commit()
    n = evict(db, cfg, day=60)
    assert n == 1
    row = db.execute("SELECT deleted_at FROM items WHERE content='junk'").fetchone()
    assert row["deleted_at"] is not None


def test_protected_survives_eviction(db, cfg):
    for i in range(10):
        _add(db, f"good {i}", 8, 2, vec_row=300 + i)
    _add(db, "Anya", 0.2, 9, protected=1, vec_row=400)
    db.commit()
    evict(db, cfg, day=60)
    assert db.execute("SELECT deleted_at FROM items WHERE content='Anya'"
                      ).fetchone()["deleted_at"] is None


def test_eviction_no_data_is_safe(db, cfg):
    assert evict(db, cfg, day=60) == 0


def test_meta_roundtrip(db):
    set_meta(db, "day", 12)
    assert get_meta(db, "day") == "12"
    assert get_meta(db, "missing", "dflt") == "dflt"
