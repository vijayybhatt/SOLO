"""The parser and the exception surface -- both cost real bugs."""
import pytest
from solo.llm import parse_score, parse_choice, guarded, LLM_ERRORS

REAL_MODEL_OUTPUTS = [
    ('{"score": 0.8, "reason": "concise"}', 0.8),
    ('```json\n{"score": 0.8}\n```', 0.8),
    ('Here is my assessment:\n{"score": 0.8}', 0.8),
    ('{"score": 0.8, "reason": "x",}', 0.8),
    ("{'score': 0.8}", 0.8),
    ('{"score": "0.8"}', 0.8),
    ('{"score": 8}', 0.8),                 # 0-10 scale -> silent corruption if naive
    ('{\n  "score": 0.8\n', 0.8),
    ('The score is 0.8 because it was concise.', 0.8),
    ('{"score": 0.8}\n{"score": 0.9}', 0.8),
    ('<think>hmm</think>{"score":0.8}', 0.8),
]


@pytest.mark.parametrize("raw,expected", REAL_MODEL_OUTPUTS)
def test_parse_score_survives_real_output(raw, expected):
    assert parse_score(raw) == pytest.approx(expected, abs=1e-6)


def test_naive_json_would_fail():
    import json
    ok = 0
    for raw, _ in REAL_MODEL_OUTPUTS:
        try:
            json.loads(raw); ok += 1
        except Exception:
            pass
    assert ok <= 3, "if naive parsing improved, revisit the robust parser"


def test_ten_scale_is_normalised_not_clipped():
    assert parse_score('{"score": 8}') == pytest.approx(0.8)


def test_empty_and_garbage():
    assert parse_score("") is None
    assert parse_score(None) is None
    assert parse_score("   ") is None


def test_parse_choice():
    assert parse_choice("NEW", ["NEW", "CONTINUE"], "CONTINUE") == "NEW"
    assert parse_choice('"continue".', ["NEW", "CONTINUE"], "NEW") == "CONTINUE"
    assert parse_choice(None, ["NEW"], "NEW") == "NEW"


def test_openai_errors_are_not_builtins():
    """The bug that made guarded() catch nothing."""
    openai = pytest.importorskip("openai")
    for exc in (openai.APIConnectionError, openai.APITimeoutError, openai.OpenAIError):
        assert not issubclass(exc, (ConnectionError, TimeoutError)), \
            f"{exc.__name__} is a builtin now -- simplify LLM_ERRORS"
        assert exc in LLM_ERRORS or any(issubclass(exc, e) for e in LLM_ERRORS)


def test_guarded_catches_client_errors():
    openai = pytest.importorskip("openai")
    def boom():
        raise openai.APIConnectionError(request=None)
    assert guarded(boom, "fallback") == "fallback"


def test_guarded_reraises_real_bugs():
    def boom():
        raise KeyError("a genuine programming error")
    with pytest.raises(KeyError):
        guarded(boom, "fallback")


def test_available_models_distinguishes_unreachable_from_empty(cfg):
    """guarded() returning [] made doctor report an unreachable server as OK."""
    from solo.llm import LLMClient
    c = LLMClient(type(cfg)(base_url="http://127.0.0.1:9/v1"))
    assert c.available_models() is None      # unreachable, not []
    assert c.ping() is False
