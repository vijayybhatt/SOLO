"""Behaviour over time. These are the properties the whole design exists for."""
import numpy as np, pytest
from solo.config import Config
from solo.db import connect
from solo.embed import EmbedStore
from solo.engine import Engine
from conftest import FakeLLM

TOPICS = ["python deploy pipeline", "family school daughter", "azure sql database",
          "short concise answers", "project deadline client", "weather travel",
          "debug error trace", "draft email vendor"]
HELPFUL = {0, 1, 2, 3}


def _run(cfg, days=45, per_day=20, seed=3):
    llm = FakeLLM(seed=seed)
    db = connect(cfg.db_path)
    emb = EmbedStore(cfg.npy_path, cfg.embed_dim, llm)
    rng = np.random.default_rng(seed)
    eng = Engine(cfg, db=db, emb=emb, llm=llm, rng=rng)
    for t, topic in enumerate(TOPICS):
        for i in range(6):
            eng.ingest_now([{"content": f"{topic} detail {i}"}])
    for _ in range(days):
        for _ in range(per_day):
            t = int(rng.integers(0, len(TOPICS)))
            out = eng.chat(f"{TOPICS[t]} query {rng.integers(0, 99999)}", generate=False)
            p = 0.80 if t in HELPFUL else 0.40
            ev = "explicit_positive" if rng.random() < p else "failure"
            if rng.random() < 0.4:
                ev = "neutral"
            eng.record_outcome(out["interaction_id"], ev)
        eng.nightly()
    return eng


@pytest.mark.slow
def test_no_crash_over_45_days(cfg):
    eng = _run(cfg)
    n = eng.db.execute("SELECT count(*) c FROM interactions").fetchone()["c"]
    assert n == 45 * 20


@pytest.mark.slow
def test_posteriors_do_not_drift_upward(cfg):
    """Replicating rewards drove the mean to 0.729 and climbing."""
    eng = _run(cfg)
    mean = float(np.mean(eng.alpha / (eng.alpha + eng.beta + 1e-9)))
    assert 0.02 < mean < 0.60, f"mean posterior {mean:.3f} suggests drift"


@pytest.mark.slow
def test_evidence_respects_decay_ceiling(cfg):
    eng = _run(cfg)
    obs = eng.alpha + eng.beta
    gain = float(np.median(obs)) * (1 - cfg.decay)
    ceiling = cfg.equilibrium_obs(max(gain, 1e-9))
    assert obs.max() <= ceiling * 3, "evidence exceeded the decay ceiling"


@pytest.mark.slow
def test_shadow_ab_is_recorded_throughout(cfg):
    eng = _run(cfg, days=20)
    rows = eng.db.execute("""
        SELECT AVG(o) a FROM (
          SELECT (SELECT count(*) FROM retrievals r JOIN shadow s
                    ON s.interaction_id=r.interaction_id AND s.item_id=r.item_id
                   WHERE r.interaction_id=i.id) AS o
          FROM interactions i)""").fetchone()
    assert rows["a"] is not None
    h = eng.health()
    assert h["shadow_divergence"] is not None
    assert 0.0 <= h["shadow_divergence"] <= 1.0


@pytest.mark.slow
def test_health_snapshot_is_sane(cfg):
    eng = _run(cfg, days=35)
    h = eng.health()
    assert h["day"] == 35
    assert h["items"] > 0
    assert h["hot_path_p99_ms"] < 100
    assert h["pos_neg_ratio"] > 0
