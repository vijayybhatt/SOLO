import numpy as np, pytest
from solo.reward import apply_reward, decay_evidence, reward_for
from solo.config import Config


def test_positive_is_split_not_replicated(cfg):
    """Replicating gives a 10:1 drift; splitting gives 1.3:1."""
    a = np.zeros(10); b = np.zeros(10)
    ga = np.ones(3); gb = np.full(3, 9.0)
    groups = np.zeros(10, dtype=np.int64)
    rows = np.arange(8)
    apply_reward(1.0, rows, a, b, ga, gb, groups, cfg)
    assert a[0] == pytest.approx(0.125)
    assert a.sum() == pytest.approx(1.0)          # exactly one unit of credit
    assert (ga.sum() - 3.0) == pytest.approx(1.0)


def test_replication_would_inflate(cfg):
    c2 = Config(split_positive=False)
    a = np.zeros(10); b = np.zeros(10)
    ga = np.ones(3); gb = np.full(3, 9.0); g = np.zeros(10, dtype=np.int64)
    apply_reward(1.0, np.arange(8), a, b, ga, gb, g, c2)
    assert a.sum() == pytest.approx(8.0)          # 8x the credit -> the drift bug


def test_negative_hits_only_the_culprit(cfg):
    a = np.zeros(10); b = np.zeros(10)
    ga = np.ones(3); gb = np.full(3, 9.0); g = np.zeros(10, dtype=np.int64)
    apply_reward(-1.0, np.arange(8), a, b, ga, gb, g, cfg, culprit=3)
    assert b[3] == pytest.approx(1.0)
    assert b.sum() == pytest.approx(1.0)


def test_blame_all_fallback(cfg):
    a = np.zeros(10); b = np.zeros(10)
    ga = np.ones(3); gb = np.full(3, 9.0); g = np.zeros(10, dtype=np.int64)
    apply_reward(-1.0, np.arange(8), a, b, ga, gb, g, cfg, culprit=None)
    assert b[:8].sum() == pytest.approx(8 * abs(cfg.blame_all))


def test_neutral_never_updates(cfg):
    a = np.zeros(5); b = np.zeros(5)
    ga = np.ones(2); gb = np.full(2, 9.0); g = np.zeros(5, dtype=np.int64)
    apply_reward(0.0, np.arange(5), a, b, ga, gb, g, cfg)
    assert a.sum() == 0 and b.sum() == 0


def test_decay_preserves_mean_shrinks_confidence(cfg):
    """Decay makes a score correctable, it does not correct it."""
    a = np.array([50.0]); b = np.array([10.0])
    ga = np.array([1.0]); gb = np.array([9.0])
    m0 = a[0] / (a[0] + b[0])
    for _ in range(70):
        decay_evidence(a, b, ga, gb, cfg)
    assert a[0] / (a[0] + b[0]) == pytest.approx(m0, abs=1e-9)   # mean unchanged
    assert (a[0] + b[0]) < 60 * 0.6                              # confidence shrunk


def test_decay_pulls_groups_to_prior_not_zero(cfg):
    ga = np.array([100.0]); gb = np.array([50.0])
    a = np.zeros(1); b = np.zeros(1)
    for _ in range(2000):
        decay_evidence(a, b, ga, gb, cfg)
    assert ga[0] == pytest.approx(cfg.prior_a, abs=1e-3)
    assert gb[0] == pytest.approx(cfg.prior_b, abs=1e-3)


def test_reward_table(cfg):
    assert reward_for("explicit_positive", cfg) == 1.0
    assert reward_for("moved_on", cfg) == 0.5
    assert reward_for("no_return", cfg) == 0.0      # rage-quit == satisfaction
    assert reward_for("failure", cfg) == -1.0
