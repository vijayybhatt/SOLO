import pytest
from solo.ingest import (route, assign_group, is_protected, is_explicit,
                         parse_facts, parse_rules, ingest)


def test_contradiction_beats_dedup(cfg):
    """With the checks reversed, 'Ananya not Anya' is dropped as a duplicate."""
    assert route(0.95, True, cfg) == "SUPERSEDE"
    assert route(0.99, True, cfg) == "SUPERSEDE"
    assert route(0.99, False, cfg) == "DROP_DUPLICATE"
    assert route(0.85, False, cfg) == "MERGE_OR_SKIP"
    assert route(0.40, False, cfg) == "INSERT_NEW"


@pytest.mark.parametrize("text,expected", [
    ("My daughter Anya starts school", "personal"),
    ("reach me at raj@example.com", "personal"),      # PATTERN not the word "email"
    ("call me on +91 98765 43210", "personal"),
    ("I prefer short answers", "preference"),
    ("we deploy on azure pipelines", "technical"),
    ("the client deadline is Friday", "project"),
    ("the weather was nice", "episodic"),
])
def test_group_assignment(text, expected):
    assert assign_group(text) == expected


@pytest.mark.parametrize("text", [
    "My daughter Anya", "raj@example.com", "+91 98765 43210",
    "his medication schedule",
])
def test_protection_fails_safe(text):
    assert is_protected(text)


def test_unprotected_ordinary_text():
    assert not is_protected("use enumerate instead of range(len(x))")


def test_explicit_instruction_detection():
    assert is_explicit("Remember my daughter's name is Anya")
    assert is_explicit("From now on keep answers short")
    assert not is_explicit("what is the capital of France")


def test_extraction_hard_cap_in_code(cfg):
    """One turn yielded 12 candidates unbounded -> 29,200 items/year."""
    raw = "\n".join(f"FACT|normal|fact {i}" for i in range(12))
    assert len(parse_facts(raw, cfg.extract_cap)) == cfg.extract_cap


def test_parse_none_sentinel(cfg):
    assert parse_facts("NONE", 5) == []
    assert parse_rules("NONE", 3) == []
    assert parse_facts("", 5) == []


def test_parse_facts_marks_protected():
    out = parse_facts("FACT|protected|daughter is Anya\nFACT|normal|likes python", 5)
    assert out[0]["protected"] and not out[1]["protected"]


def test_ingest_caps_and_dedups(cfg, db, emb, llm):
    cands = [{"content": f"user deploys with azure pipeline variant {i}"} for i in range(9)]
    st = ingest(db, emb, cands, cfg, llm)
    assert st["inserted"] + st["dropped"] + st["skipped"] + st["superseded"] == cfg.extract_cap
    n = db.execute("SELECT count(*) c FROM items").fetchone()["c"]
    assert n == st["inserted"] + st["superseded"]


def test_ingest_identical_text_is_dropped(cfg, db, emb, llm):
    ingest(db, emb, [{"content": "user prefers short answers"}], cfg, llm)
    st = ingest(db, emb, [{"content": "user prefers short answers"}], cfg, llm)
    assert st["dropped"] == 1
    assert db.execute("SELECT count(*) c FROM items").fetchone()["c"] == 1
