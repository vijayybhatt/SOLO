import numpy as np, pytest
from solo.retrieve import retrieve, pooled_params
from solo.config import Config


def _fixture(n=60, seed=0):
    rng = np.random.default_rng(seed)
    e = rng.standard_normal((n, 384)).astype(np.float32)
    e /= np.linalg.norm(e, axis=1, keepdims=True)
    return e, np.zeros(n), np.zeros(n), np.full(n, 1.0), np.full(n, 9.0)


def test_phi_clamp_prevents_beta_zero_crash(cfg, rng):
    """Beta(0, x) raises ValueError. A group at all-wins or all-losses hits this."""
    a = np.zeros(5); b = np.zeros(5)
    for ga, gb in [(0.0, 10.0), (10.0, 0.0), (0.0, 0.0)]:
        ae, be = pooled_params(a, b, np.full(5, ga), np.full(5, gb), cfg)
        assert (ae > 0).all() and (be > 0).all()
        rng.beta(ae, be)          # must not raise


def test_leave_one_out_pooling(cfg):
    """An item must not inform its own prior."""
    a = np.array([30.0]); b = np.array([10.0])
    ga = np.array([40.0]); gb = np.array([60.0])      # group includes this item
    ae, be = pooled_params(a, b, ga, gb, cfg)
    naive_phi = 40.0 / 100.0
    loo_phi = (40.0 - 30.0) / ((40.0 - 30.0) + (60.0 - 10.0))
    assert abs((ae - a[0]) / cfg.kappa - loo_phi) < 1e-9
    assert abs((ae - a[0]) / cfg.kappa - naive_phi) > 1e-3


def test_propensity_sums_over_all_candidates(cfg, rng):
    """Sums to n_retrieve over ALL candidates, 2-6 over the chosen subset."""
    e, a, b, ga, gb = _fixture(n=50)
    cfg.n_candidate = 50
    sim = e @ e[0]
    a_eff, b_eff = pooled_params(a, b, ga, gb, cfg)
    draws = rng.beta(a_eff, b_eff, size=(4000, 50))
    ranks = np.argsort(-(sim * draws), axis=1)[:, :cfg.n_retrieve]
    prop = np.bincount(ranks.ravel(), minlength=50) / 4000
    assert prop.sum() == pytest.approx(cfg.n_retrieve, rel=0.02)
    r = retrieve(e[0], e, a, b, ga, gb, cfg, rng)
    assert 1.0 < r["prop"].sum() < cfg.n_retrieve      # chosen subset is lower


def test_propensity_floor_bounds_ips_weight(cfg, rng):
    e, a, b, ga, gb = _fixture()
    r = retrieve(e[0], e, a, b, ga, gb, cfg, rng)
    assert (r["prop"] >= cfg.prop_floor).all()
    assert (1.0 / r["prop"]).max() <= 1.0 / cfg.prop_floor <= 200


@pytest.mark.parametrize("n", [0, 1, 3, 7])
def test_cold_start_never_crashes(cfg, rng, n):
    e, a, b, ga, gb = _fixture(n=max(n, 1))
    e, a, b, ga, gb = e[:n], a[:n], b[:n], ga[:n], gb[:n]
    q = np.zeros(384, np.float32); q[0] = 1.0
    r = retrieve(q, e, a, b, ga, gb, cfg, rng)
    assert len(r["chosen"]) == min(n, cfg.n_retrieve)


def test_shadow_is_pure_similarity(cfg, rng):
    e, a, b, ga, gb = _fixture()
    r = retrieve(e[0], e, a, b, ga, gb, cfg, rng)
    sim = e @ e[0]
    assert list(r["shadow"]) == list(np.argsort(-sim)[:cfg.n_retrieve])


def test_bootstrap_mode_equals_shadow(cfg, rng):
    e, a, b, ga, gb = _fixture()
    r = retrieve(e[0], e, a, b, ga, gb, cfg, rng, thompson=False)
    assert list(r["chosen"]) == list(r["shadow"])
