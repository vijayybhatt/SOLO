# Defects found and fixed

Every entry has a regression test. Grouped by how it was found.

## Found by executing code (would not survive review alone)

| # | Defect | Test |
|---|---|---|
| 1 | `superseded_by = -1` → `FOREIGN KEY constraint failed` | `test_db.py::test_soft_delete_uses_deleted_at_not_fk_sentinel` |
| 2 | `Beta(0, x)` → `ValueError` when a group hits all-wins/all-losses | `test_retrieve.py::test_phi_clamp_prevents_beta_zero_crash` |
| 3 | Full reward to each item → 10:1 drift, mean climbs to 0.729 | `test_reward.py::test_positive_is_split_not_replicated` |
| 4 | Absolute eviction threshold evicts 33% of the store | `test_db.py::test_eviction_thresholds_are_adaptive` |
| 5 | **Decay caps evidence below the eviction threshold — 0/96 items ever qualified** | `test_config.py::test_equilibrium_ceiling` |
| 6 | Pooling let an item inflate its own prior | `test_retrieve.py::test_leave_one_out_pooling` |
| 7 | Propensity floor 1e-3 → 1000× IPS weights | `test_retrieve.py::test_propensity_floor_bounds_ips_weight` |
| 8 | `Σ propensity ≈ 8` only over ALL candidates, not the chosen subset | `test_retrieve.py::test_propensity_sums_over_all_candidates` |
| 9 | `record_outcome` not idempotent — reward applied twice | `test_engine.py::test_record_outcome_is_idempotent` |
| 10 | Auto-scoring silently overwrote manual scores (9 of 10) | `test_engine.py::test_auto_scoring_does_not_overwrite_manual` |

## Found against a live Ollama server

| # | Defect | Test |
|---|---|---|
| 11 | **`guarded()` caught zero real failures** — `openai` exceptions are not builtins | `test_llm.py::test_openai_errors_are_not_builtins` |
| 12 | `/v1/models` returns `data: null`; `for m in resp.data` raises | `LLMClient.available_models` iterates the response |

## Found by red teaming

| # | Defect | Test |
|---|---|---|
| 13 | No evidence decay — Beta(50,10) needed 40 straight failures to fall below 0.50 | `test_reward.py::test_decay_preserves_mean_shrinks_confidence` |
| 14 | No metric could detect SOLO being worse than plain RAG | `test_longrun.py::test_shadow_ab_is_recorded_throughout` |
| 15 | Headline precision oversold — 0.93 ideal vs 0.39–0.55 realistic | documented in README |

## Found in prompts and ingest

| # | Defect | Test |
|---|---|---|
| 16 | `json.loads` handles 3/12 real outputs; `{"score": 8}` → 8.0 silently | `test_llm.py::test_parse_score_survives_real_output` |
| 17 | Dedup checked before contradiction → corrections dropped | `test_ingest.py::test_contradiction_beats_dedup` |
| 18 | Unbounded extraction — 12 facts/turn, 29,200 items/year | `test_ingest.py::test_extraction_hard_cap_in_code` |
| 19 | No LLM fallbacks — Ollama down crashed the app | `test_engine.py::test_survives_total_llm_failure` |
| 20 | Group regex matched the word "email", not an address | `test_ingest.py::test_group_assignment` |
| 21 | `moved_on` fired ~every turn — 7.7:1 over `thanks` | `test_engine.py::test_health_reports_and_flags` |

## Environment traps

| # | Trap |
|---|---|
| 22 | sqlite-vec needs `enable_load_extension`, disabled in macOS system SQLite — and is 6–9× slower than numpy |
| 23 | `pip install mlx` **exits 0 on non-Apple hardware** but the binary is broken |
| 24 | Stock `mlx-lm` has **no DPO** — no `chosen`/`rejected` support |
